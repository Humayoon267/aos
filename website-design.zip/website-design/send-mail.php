<?php
/*
if($_POST){
    $servername = "localhost";
    $username = "wwwtheor_leads";
    $password = "8h28;QQ48O34";
    $dbname = "wwwtheor_leads";
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    if(isset($_POST['name'])){
        $name = $_POST['name'];
    }else{
        $name = "";
    }
    if(isset($_POST['email'])){
        $email = $_POST['email'];
    }else{
        $email = "";
    }
    if(isset($_POST['phone'])){
        $phone = $_POST['phone'];
    }else{
        $phone = "";
    }
    if(isset($_POST['message'])){
        $message = $_POST['message'];
    }else{
        $message = "";
    }
    if(isset($_POST['country'])){
        $country = $_POST['country'];
    }else{
        $country = "";
    }
    if(isset($_POST['page_url'])){
        $page_urls = $_POST['page_url'];
    }else{
        $page_urls = "";
    }
    if(isset($_POST['interested_in'])){
        $interested = $_POST['interested_in'];
    }else{
        $interested = "";
    }
    if(isset($_POST['budget'])){
        $budget = $_POST['budget'];
    }else{
        $budget = "";
    }
    if(isset($_POST['package'])){
        $package = $_POST['package'];
    }else{
        $package = "";
    }
    if(isset($_POST['package_price'])){
        $package_price = $_POST['package_price'];
    }else{
        $package_price = "";
    }
    if(isset($_POST['business_description'])){
        $business_description = $_POST['business_description'];
    }else{
        $business_description = "";
    }
    if(isset($_POST['design_peception'])){
        $design_peception = $_POST['design_peception'];
    }else{
        $design_peception = "";
    }
    if(isset($_POST['additional_comments'])){
        $additional_comments = $_POST['additional_comments'];
    }else{
        $additional_comments = "";
    }
    $sql = "INSERT INTO inquiries (name, email, phonenumber, page_url, message, country, interested, budget, package, package_price, business_description, design_peception, additional_comments)
    VALUES ('".$name."', '".$email."', '".$phone."','".$page_urls."','".$message."','".$country."','".$interested."','".$budget."','".$package."','".$package_price."','".$business_description."','".$design_peception."','".$additional_comments."')";
    if ($conn->query($sql) === TRUE) {
      //echo "New record created successfully";
    } else {
      //echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}
*/
function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE) {
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose    = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
    $support    = array("country", "countrycode", "state", "region", "city", "location", "address");
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city"           => @$ipdat->geoplugin_city,
                        "state"          => @$ipdat->geoplugin_regionName,
                        "country"        => @$ipdat->geoplugin_countryName,
                        "country_code"   => @$ipdat->geoplugin_countryCode,
                        "continent"      => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "address":
                    $address = array($ipdat->geoplugin_countryName);
                    if (@strlen($ipdat->geoplugin_regionName) >= 1)
                        $address[] = $ipdat->geoplugin_regionName;
                    if (@strlen($ipdat->geoplugin_city) >= 1)
                        $address[] = $ipdat->geoplugin_city;
                    $output = implode(", ", array_reverse($address));
                    break;
                case "city":
                    $output = @$ipdat->geoplugin_city;
                    break;
                case "state":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
                case "country":
                    $output = @$ipdat->geoplugin_countryName;
                    break;
                case "countrycode":
                    $output = @$ipdat->geoplugin_countryCode;
                    break;
            }
        }
    }
    return $output;
}
if(isset($_POST['g-recaptcha-response']) && ($_POST['g-recaptcha-response'] != ""))
     {
         $secret = '6LddrLgUAAAAACS917HHbLJeHRHI_ynxZmRqd8fD';
         $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$secret.'&response='.$_POST['g-recaptcha-response']);
         $response = json_decode($verifyResponse);
            if($response->success){
             }
            else{
                header("location:index.php?error=Robot verification failed, please try again&name=".$_POST['name']."&email=".$_POST['email']."&phone=".$_POST['phone']."&message=".$_POST['message']."&form=".$_POST['form']);
                echo "<script>window.location.href='index.php?error=Robot verification failed, please try again';</script>";
                return false;
             }
    }else{
        header("location:index.php?error=Robot verification failed, please try again&name=".$_POST['name']."&email=".$_POST['email']."&phone=".$_POST['phone']."&message=".$_POST['message']."&form=".$_POST['form']);
        echo "<script>window.location.href='index.php?error=Robot verification failed, please try again';</script>";
        return false;
    }
$body='';
$body='<table style="width:100%;" border="1">';
	// echo "<pre>";
	// print_r($_POST);
	// exit();
foreach($_POST as $key=>$value){
if ($value=='undefined'||$value=='' || $key == "ServicesSelect") {
}else{
	 $_key=ucwords(str_replace('_',' ',$key));
    $body.="<tr><td>$_key</td><td>$value</td></tr>";
}
}
$body.='</table>';
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$subject='Lead LP - Pinnacle Icons';
$headers .= array(
    'From' => 'info@pinnacleicons.com',
    'X-Mailer' => 'PHP/' . phpversion()
);
  $mailSent=mail("bundle@thecreativewebsitestudios.com",$subject,$body,$headers);
  $mailSent=mail("alex.wright@creativewebsitestudios.com",$subject,$body,$headers);
  $mailSent=mail("signup-form@pinnacleicons.com",$subject,$body,$headers);
            if($mailSent){
            //     $isSuccess = true;
            //   $msg = 'Thank you for contacting us, we will get back to you soon';
            header("location:https://pinnacleicons.com/lp/website-design/thankyou.php");
            }else{
                header("location:https://pinnacleicons.com/lp/website-design/thankyou.php?error=true");
            //     echo 'Message could not be sent.';
            //   echo 'Mailer Error: ' . $mail->ErrorInfo;
            }
?>