<?php include 'includes/header.php';?>


<!-- Banner Section Begin -->
  
    <section class="banner_Sec_main">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-5">
            <div class="banner_content_sec">
              <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Let’s Execute Your Idea,  <span>Together!</span></h2>

              <div class="banner-btn wow fadeIn" data-wow-duration=".6s" data-wow-delay=".8s">
                <ul>
                  <li><a data-toggle="modal" data-target="#started_pop">Get Custom Quote</a></li>
                  <li class="chng_clr"><a href="javascript:;" onclick="$zopim.livechat.window.toggle()">Schedule a Call </a></li>
                </ul>
              </div>

              <div class="banner_vector">
                <ul>
                  <li><a href="#" class="wow zoomIn" data-wow-duration=".6s" data-wow-delay=".7s"><img src="assets/images/trust_logo.png"></a></li>
                  <li><a href="#" class="wow zoomIn" data-wow-duration=".6s" data-wow-delay=".8s"><img src="assets/images/topdigi.png"></a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-sm-7">
            <div class="banner_right_img banner_slider">
              <div class="banner_img_tab">
                <img src="assets/images/inner-bnr1.png" class="img-fluid" alt="">
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>

<!-- Banner Section End -->


<!-- Form Section Begin -->
  
  <section class="form_Sec_main padding_70">
    <div class="container-fluid p-0">
      <div class="row align-items-center">
        <div class="col-sm-6 p-0">
          <div class="form_sec_left">
            <img src="assets/images/form-banner.jpg" class="img-fluid" alt="">
          </div>
        </div>
        <div class="col-sm-6 p-0">
          <div class="form_sec_tab">
            <h4 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Need An Urgent Website Developer For your Business? Unlock a 23% Discounted Coupon.</h4>
            <div class="cta_form">
              <form action="sendmail.php" method="POST">
                <div class="row">
                  <div class="col-md-6">
                    <input type="text" name="Name" class="form-control" placeholder="Your Name" required="">
                  </div>
                  <div class="col-md-6">
                    <input type="text" name="Email" class="form-control" placeholder="Email Address" required="">
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="intl-tel-input separate-dial-code">
                      <div class="flag-container">
                        <div class="selected-flag" title="Unknown">
                          <div class="iti-flag "></div>
                          <div class="selected-dial-code"></div>
                        </div>
                      </div>
                      <input id="phone-country" name="Number" rangelength="[7,12]" type="number" placeholder="Phone Number" required="" class="cta-phone" autocomplete="off">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <textarea name="Message" class="form-control" placeholder="Your Message"></textarea>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="btn_form">
                      <input type="submit" value="Submit">
                      <input type="hidden" name="ctry" value="">
                      <input type="hidden" name="pc" value="">
                      <input type="hidden" name="cip" value="">
                      <input type="hidden" name="hiddencapcha" value="">
                      <input type="hidden" id="location" name="websiteURL" value="index.html" />
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<!-- Form Section End -->



<!-- Custom Website Design Section Begin -->
  
  <section class="custom_web padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="web_head text-center">
            <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Your Business Websites Needs A Custom Website Development To Stand Out. </h2>
          </div>
        </div>
      </div>

      <div class="row pt-5">
        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".4s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-1.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>SEO-Friendly & Responsive</h4>
              <p>What good is a website if no one ever views it? To be visible to your target audience, your website must be responsive and SEO-friendly.</p>
            </div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".5s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-2.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>App Integrations</h4>
              <p>Our incorporated app integrations help retailers save time and money by reducing administrative tasks and boosting user experience and functionality.</p>
            </div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".6s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-3.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>Content Management System</h4>
              <p>Your E-commerce platform's administrator has the authority to alter or add content. The administration interface is more basic and user-friendly.</p>
            </div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".7s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-4.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>Quick Load Time</h4>
              <p>You can achieve lightning-fast load speeds and provide your customers a terrific online buying experience with Custom Website Development.</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>

<!-- Custom Website Design Section End -->



<!-- Cilent Review Section Begin -->
  
  <section class="review_sec_main padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="web_head text-center">
            <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".4s">Why Our Clients Are Happy To Share Reviews?</h2>
          </div>
        </div>
      </div>

      <div class="row pt-5">
        <div class="col-sm-6">
          <div class="review_sec_tab">
            <div class="review_content">
              <p>I had a fantastic time working with the entire The Website Designs   team. They were knowledgeable, competent, and patient with all of our needs. During the building of our website, their procedure was outstanding. The The Website Designs   team provided me with what I requested. Based on my own experience, I highly suggest The Website Designs  .</p>
            </div>

            <div class="review_author">
              <div class="author_name">
                <h3>Allan</h3>
                <div class="rating_sec">
                  <ul>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                  </ul>
                </div>
              </div>

              <div class="trustpilot-logo">
                <img src="assets/images/trust_logo.png" class="img-fluid" alt="">
              </div>

            </div>

          </div>
        </div>
        <div class="col-sm-6">
          <div class="review_sec_tab">
            <div class="review_content">
              <p>The Website Designs  's crew is always quick to respond. They paved the way for my accomplishment. Our website was developed in such a way that it is simple for me to edit. As someone who does not write HTML code, I am confident in my ability to complete many of our website improvements without the need for assistance. But I know that if I ask for assistance, the The Website Designs   team will make it look excellent and quickly.</p>
            </div>

            <div class="review_author">
              <div class="author_name">
                <h3>Robert</h3>
                <div class="rating_sec">
                  <ul>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                  </ul>
                </div>
              </div>

              <div class="trustpilot-logo">
                <img src="assets/images/trust_logo.png" class="img-fluid" alt="">
              </div>

            </div>

          </div>
        </div>
      </div>

    </div>
  </section>

<!-- Cilent Review Section End -->

<?php include 'includes/footer.php';?>
