<?php include 'includes/header.php';?>


<!-- Banner Section Begin -->  
    <section class="banner_Sec_main inner-port">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-5">
            <div class="banner_content_sec">
              <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Custom Made Exceptional <span>Portfolio</span></h2>
              <div class="banner-btn wow fadeIn" data-wow-duration=".6s" data-wow-delay=".8s">
                <ul>
                  <li><a data-toggle="modal" data-target="#started_pop">Get Custom Quote</a></li>
                  <li class="chng_clr"><a href="javascript:;" onclick="$zopim.livechat.window.toggle()">Schedule a Call </a></li>
                </ul>
              </div>

              <div class="banner_vector">
                <ul>
                  <li><a href="#" class="wow zoomIn" data-wow-duration=".6s" data-wow-delay=".7s"><img src="assets/images/trust_logo.png"></a></li>
                  <li><a href="#" class="wow zoomIn" data-wow-duration=".6s" data-wow-delay=".8s"><img src="assets/images/topdigi.png"></a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-sm-7">
            <div class="banner_right_img banner_slider">
              <div class="banner_img_tab">
                <img src="assets/images/inner-bnr2.png" class="img-fluid" alt="">
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>

<!-- Banner Section End -->


<!-- Portfolio Section Begin -->
  
    <section class="portfolio_Sec_main">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="portfolio_heading">
              <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">The Website Designs Proudly Presents Its Portfolio.</h2>
              <div class="row">
                <div class="col-12 col-lg-7">
                  <p class="wow fadeIn" data-wow-duration=".6s" data-wow-delay=".5s">
                    Our goal is to provide businesses with high-quality digital marketing, web design, and development services at affordable prices. We've helped several companies and businesses by delivering exceptional website design and development bound to significantly improve the overall client experience.
                  </p>
                </div>
                <div class="col-12 col-lg-5 text-right">
                  <a href="javascript:;" onclick="setButtonURL();" class="arrowBtn">Let's Discuss</a>
                  <a href="tel:+1 877-313-0324" class="arrowBtn change_btn">+1 877-313-0324</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="tab_portfolio">
              <ul class="nav nav-tabs">

                <li class="nav-item">
                  <a class="nav-link active show" data-toggle="tab" href="#Randon-port">All </a>
                </li>


                <li class="nav-item">
                  <a class="nav-link " data-toggle="tab" href="#Beauty">Beauty</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#Auto">Auto</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#RealEstate">Real Estate</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#ecommerce-port">E-commerce</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#cbd-port">CBD </a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#education-port">Education </a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#fitness-port">Fitness </a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#food-port">Food </a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#health-port">Health </a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#non-profit-port">Non Profit </a>
                </li>

                
              </ul>
            </div>
          </div>
        </div>
      </div>

        <div class="tab-content">

          <div class="tab-pane active" id="Randon-port">
            <div class="container-fluid ">
              <div class="row">

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>


                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                

                

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane " id="Beauty">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>


          <div class="tab-pane" id="Auto">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="RealEstate">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="ecommerce-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="cbd-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="education-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="fitness-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="food-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="health-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="non-profit-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          
        </div>
    </section>

<!-- Portfolio Section End -->


<!-- Industries Section Begin -->
  
  <section class="industry_sec_tab padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="web_head text-center">
            <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Our Service expands to a plethora of Industries</h2>
            <p class="wow fadeInUp" data-wow-duration=".6s" data-wow-delay=".5s">The Website Designs  's development team specializes in coming up with innovative solutions for customers in a wide range of industries. Dedicated Website Designer assisting companies in the travel, hotel, education, and healthcare industries, among others...</p>
          </div>
        </div>
      </div>

      <div class="row pt-5">
        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".3s">
            <img src="assets/images/indus-i2.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".4s">
            <img src="assets/images/indus-i.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".5s">
            <img src="assets/images/indus-i2.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".6s">
            <img src="assets/images/indus-i3.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".7s">
            <img src="assets/images/indus-i4.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".8s">
            <img src="assets/images/indus-i5.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".9s">
            <img src="assets/images/indus-i6.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay="1s">
            <img src="assets/images/indus-i7.png" class="img-fluid" alt="">
          </div>
        </div>
      </div>

    </div>
  </section>

<!-- Industries Section End -->



<!-- Custom Website Design Section Begin -->
  
  <section class="custom_web padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="web_head text-center">
            <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Your Business Websites Needs A Custom Website Development To Stand Out. </h2>
          </div>
        </div>
      </div>

      <div class="row pt-5">
        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".4s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-1.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>SEO-Friendly & Responsive</h4>
              <p>What good is a website if no one ever views it? To be visible to your target audience, your website must be responsive and SEO-friendly.</p>
            </div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".5s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-2.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>App Integrations</h4>
              <p>Our incorporated app integrations help retailers save time and money by reducing administrative tasks and boosting user experience and functionality.</p>
            </div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".6s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-3.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>Content Management System</h4>
              <p>Your E-commerce platform's administrator has the authority to alter or add content. The administration interface is more basic and user-friendly.</p>
            </div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".7s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-4.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>Quick Load Time</h4>
              <p>You can achieve lightning-fast load speeds and provide your customers a terrific online buying experience with Custom Website Development.</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>

<!-- Custom Website Design Section End -->



<!-- Cilent Review Section Begin -->
  
  <section class="review_sec_main padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="web_head text-center">
            <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".4s">Why Our Clients Are Happy To Share Reviews?</h2>
          </div>
        </div>
      </div>

      <div class="row pt-5">
        <div class="col-sm-6">
          <div class="review_sec_tab">
            <div class="review_content">
              <p>I had a fantastic time working with the entire The Website Designs   team. They were knowledgeable, competent, and patient with all of our needs. During the building of our website, their procedure was outstanding. The The Website Designs   team provided me with what I requested. Based on my own experience, I highly suggest The Website Designs  .</p>
            </div>

            <div class="review_author">
              <div class="author_name">
                <h3>Allan</h3>
                <div class="rating_sec">
                  <ul>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                  </ul>
                </div>
              </div>

              <div class="trustpilot-logo">
                <img src="assets/images/trust_logo.png" class="img-fluid" alt="">
              </div>

            </div>

          </div>
        </div>
        <div class="col-sm-6">
          <div class="review_sec_tab">
            <div class="review_content">
              <p>The Website Designs  's crew is always quick to respond. They paved the way for my accomplishment. Our website was developed in such a way that it is simple for me to edit. As someone who does not write HTML code, I am confident in my ability to complete many of our website improvements without the need for assistance. But I know that if I ask for assistance, the The Website Designs   team will make it look excellent and quickly.</p>
            </div>

            <div class="review_author">
              <div class="author_name">
                <h3>Robert</h3>
                <div class="rating_sec">
                  <ul>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                  </ul>
                </div>
              </div>

              <div class="trustpilot-logo">
                <img src="assets/images/trust_logo.png" class="img-fluid" alt="">
              </div>

            </div>

          </div>
        </div>
      </div>

    </div>
  </section>

<!-- Cilent Review Section End -->

<?php include 'includes/footer.php';?>
