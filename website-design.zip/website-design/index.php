<?php include 'includes/header.php';?>

<!-- Banner Section Begin -->
  
    <section class="banner_Sec_main">
      <div class="container">
        <div class="row">
          <div class="col-sm-5">
            <div class="banner_content_sec">
              <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Build A Website For Your Business With    <span>One-Time Payment.</span></h2>

              <p class="wow fadeInUp" data-wow-duration=".6s" data-wow-delay=".6s">We can build a business website for your products and services with only one-time payment. It is time to capture ideal leads and grow conversions online.</p>

              <div class="banner-btn wow fadeIn" data-wow-duration=".6s" data-wow-delay=".8s">
                <ul>
                  <li><a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,2)">Get Custom Quote</a></li>
                  <li class="chng_clr"><a href="javascript:;" onclick="$zopim.livechat.window.toggle()">Schedule a Call </a></li>
                </ul>
              </div>

              <div class="banner_vector">
                <ul>
                  <li><a href="#" class="wow zoomIn" data-wow-duration=".6s" data-wow-delay=".7s"><img src="assets/images/trust_logo.png"></a></li>
                  <li><a href="#" class="wow zoomIn" data-wow-duration=".6s" data-wow-delay=".8s"><img src="assets/images/topdigi.png"></a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-sm-7">
          <div class="head-form">
          <div class="form-head">
            <h2>Chat With Us to Avail <span>50%</span> Discount </h2>
          </div>
          <div class="inner-pages-form">
            <!--novalidate="novalidate"-->
            <form action="sendmail.php" method="POST" class="leadForm" enctype="multipart/form-data">
                          <input type="hidden" name="brand_name" value="instantwebmakers.com/lp-web">
                          <input id="lead_area" type="hidden" name="lead_area" value="">
              <div class="row">
                <div class="form-group col-md-12">
                  <input type="text" class="form-control" name="name" placeholder="Name" required="">
                </div>
                <div class="form-group col-md-12">
                  <input type="email" class="form-control" name="email" placeholder="Email" required="">
                </div>
                <div class="form-group col-md-12">
                  <input id="phone-country" type="tel" class="form-control phone" name="phone" placeholder="Phone Number" required="" maxlength="10">
                </div>
                <div class="form-group col-md-12">
                  <textarea name="Message" cols="30" rows="3" class="form-control" placeholder="Message" required=""></textarea>
                </div>
                <div class="col-md-12">
                  <button type="submit" name="banner_form_submit">Submit Now</button>
                  <input type="hidden" name="submit_step1" value="">
                  <!--<input type="hidden" id="location" name="locationURL" value="#">-->
                  <input type="hidden" name="order_package_name" value="Web Economy - $199" class="package_name">
                  <input type="hidden" name="order_package_price" value="199" class="package_price" id="package_price2">
                  <!--<input type="hidden" name="hiddencapcha" value="">-->
                  <!--<input type="hidden" name="cip" value="">-->
                  <!--<input class="" type="hidden" name="ctry" value=" ">-->
                  <!--<input type="hidden" name="portal_leadid" value="">-->
                  <!--<input type="hidden" name="pc" value="">-->
                <!--  <div class="privcheck">-->
                <!--    <label class="sp2"><input type="checkbox" name="bn_emailPromotional" required=""> Please check the box to communicate via sms or email (<a href="https://websitedesignintact.com/privacy-policy">PRIVACY POLICY </a>&amp; <a href="https://websitedesignintact.com/terms-and-conditions">TERM &amp; CONDITIONS</a> - Carrier charges may apply for sms. reply stop or unsubscribe to stop to unsbscribe anytime.</label>-->
                <!--</div>-->
                </div>
              </div>
            </form>
          </div>
        </div>
            <!-- <div class="banner_right_img banner_slider">
              <div class="banner_img_tab">
                <img src="assets/images/build-banner1-new.png" class="img-fluid" alt="">
              </div>

              <div class="banner_img_tab">
                <img src="assets/images/build-banner2-new.png" class="img-fluid" alt="">
              </div>

              <div class="banner_img_tab">
                <img src="assets/images/build-banner3.png" class="img-fluid" alt="">
              </div>

            </div> -->
          </div>

        </div>
      </div>
    </section>

<!-- Banner Section End -->


<!-- Solutions Section Begin -->
  
  <!--<section class="solutions-situation_sec padding_70">-->
  <!--  <div class="container">-->
  <!--    <div class="row">-->
  <!--      <div class="col-sm-12">-->
  <!--        <div class="web_head">-->
  <!--          <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Ge Instant Solutions To Your Web Confusions!</h2>-->
  <!--        </div>-->
  <!--      </div>-->
  <!--    </div>-->

  <!--    <div class="situation_sec_tab pt-5">-->
  <!--      <div class="row situation_box_slider">-->
  <!--        <div class="situation_box_sec">-->
  <!--          <div class="row">-->
  <!--            <div class="col-sm-7">-->
  <!--              <div class="situations_content_Sec">-->
  <!--                <h4>I already have a website. I don’t understand why I am not getting any leads at all. Can you help identify?</h4>-->
  <!--                <p>There are multiple reasons for zero lead generation through the website. However, we would love to audit your custom website and generate a report with reasoning of poor leads. Sometimes a WordPress website is not SEO optimized which could be a vital reason of your web problem.</p>-->
  <!--                <div class="banner-btn pt-5">-->
  <!--                  <ul>-->
  <!--                    <li><a data-toggle="modal" data-target="#started_pop">Consult Now</a></li>-->
  <!--                    <li class="chng_clr"><a href="javascript:;" onclick="$zopim.livechat.window.toggle()">Find Solution</a></li>-->
  <!--                  </ul>-->
  <!--                </div>-->
  <!--              </div>-->
  <!--            </div>-->
  <!--            <div class="col-sm-5">-->
  <!--              <div class="question-img">-->
  <!--                <img src="assets/images/question-img-01.png" class="img-fluid">-->
  <!--              </div>-->
  <!--            </div>-->
  <!--          </div>-->
  <!--        </div>-->

  <!--        <div class="situation_box_sec">-->
  <!--          <div class="row">-->
  <!--            <div class="col-sm-7">-->
  <!--              <div class="situations_content_Sec">-->
  <!--                <h4>My website is running very slow, and it takes forever for someone to make a purchase. What do you suggest?</h4>-->
  <!--                <p>Your website load time is affected someway. We know an e-commerce website needs all the necessary functionalities, but one should also work for web speed and performance optimization. We suggest you get your website audit from experts. Reduce unnecessary functionalities and work on the load time. We would love to assist you further and get your potential customers back in no time. Consult us right away!</p>-->
  <!--                <div class="banner-btn pt-5">-->
  <!--                  <ul>-->
  <!--                    <li><a data-toggle="modal" data-target="#started_pop">Consult Now</a></li>-->
  <!--                    <li class="chng_clr"><a href="javascript:;" onclick="$zopim.livechat.window.toggle()">Find Solution</a></li>-->
  <!--                  </ul>-->
  <!--                </div>-->
  <!--              </div>-->
  <!--            </div>-->
  <!--            <div class="col-sm-5">-->
  <!--              <div class="question-img">-->
  <!--                <img src="assets/images/question-img-02.png" class="img-fluid">-->
  <!--              </div>-->
  <!--            </div>-->
  <!--          </div>-->
  <!--        </div>-->

  <!--        <div class="situation_box_sec">-->
  <!--          <div class="row">-->
  <!--            <div class="col-sm-7">-->
  <!--              <div class="situations_content_Sec">-->
  <!--                <h4>My website development is on Joomla, and I need a WordPress website development.</h4>-->
  <!--                <p>The act of transferring the platform of your website base is called website migration. If you want your Joomla website developed on WordPress, it is a possibility a5t Pinnacle Icons. We offer website migration services and allow the same design or a better version to it. Let’s discuss it further through a call.</p>-->
  <!--                <div class="banner-btn pt-5">-->
  <!--                  <ul>-->
  <!--                    <li><a data-toggle="modal" data-target="#started_pop">Consult Now</a></li>-->
  <!--                    <li class="chng_clr"><a href="javascript:;" onclick="$zopim.livechat.window.toggle()">Find Solution</a></li>-->
  <!--                  </ul>-->
  <!--                </div>-->
  <!--              </div>-->
  <!--            </div>-->
  <!--            <div class="col-sm-5">-->
  <!--              <div class="question-img">-->
  <!--                <img src="assets/images/question-img-03.png" class="img-fluid">-->
  <!--              </div>-->
  <!--            </div>-->
  <!--          </div>-->
  <!--        </div>-->
  <!--      </div>-->
  <!--    </div>-->

  <!--  </div>-->
  <!--</section>-->

<!-- Solutions Section End -->
<!-- ======= FAQ Area ======= -->
<section id="faq-area" class="faq-area sec-padding py-70">
  <div class="container">
    <div class="row">

      <div class="col-md-4 faq-left-main">
		<img class="col-img" src="assets/images/faq-img-two.png">
      </div>


      <div class="col-md-8 faq-right">
					<div class="common-col-dark">
						<h2>We Provide <b>Services</b> That <br>Drive Results</h2> 
					<p>Here's What you need to know about our premium services</p>
					</div>

        <div class="col-md-12 faq-main">
          <div class="faq-sec">
<div id="accordion">
  <div class="card">
    <div class="card-header" id="headingOne">
      <h5 class="mb-0">
        <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
         Ecommerce Web & Store
        </button>
      </h5>
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
      <div class="card-body">
       The eCommerce website design has become a necessity for every business to excel in its growth. We are here to create your eCommerce store with all the necessary add-ons to influence potential customers.
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          WordPress Custom Website
        </button>
      </h5>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body">
       Create a basic custom WordPress website to an advanced WordPress web with essential integrations to enhance and improve user experience. Get your WordPress website designs within 24 to 48 hours.
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          Shopify Store
        </button>
      </h5>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
      <div class="card-body">
Let’s build a responsive and terrific Shopify store for all your products! Make the most out of your sales by converting maximum potential leads with our Shopify expertise and store integrations.      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingFour">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
          Web Maintenance & Revamp
        </button>
      </h5>
    </div>
    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
      <div class="card-body">
Every website needs maintenance. Get web maintenance services and let us take care of any emerging web issues and glitches and manage your web functionalities, or get a complete revamp of your website to improve UI & UX.      </div>
    </div>
  </div> 
  <div class="card">
    <div class="card-header" id="headingFive">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
          Industrial Specification
        </button>
      </h5>
    </div>
    <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordion">
      <div class="card-body">
We’ve been serving wide range of industries with diverse business norms and requirements. Each industry-specified website is designed and developed with custom functionalities to engage the target audience for conversions.      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingSix">
      <h5 class="mb-0">
        <button class="btn btn-link collapsed" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
         Web & Mobile App
        </button>
      </h5>
    </div>
    <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordion">
      <div class="card-body">
It is the era of convenience! Think out of the box and take your business to the web and mobile application technology. We will design, develop, publish, and market your app on Play Store and App Store.      </div>
    </div>
  </div>  
</div>
          </div>
        </div>
        <div class="row faq-bottom">
        	<div class="col-xl-6 left">
        		<h3>Still Have A</h3>
        		<h1>Question?</h1>
        	</div>
        	<div class="col-xl-6 right">
        		<p>Our clients describe us as a product team which creates amazing UI/UX experiencesM</p>
        		<a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,2)" class="btn_custom">Fill Out The Form</a>
        	</div>        	
        </div>

      </div>
    </div>
            <div class="row faq-row1">
        	<div class="col-xl-6 left">
        		<p><b>We Work In The Fields Of UI/UX <br>Design, Logo <b>Design</b> Website <br>Design And Animations.</b></p>
        	</div>
        	<div class="col-xl-6 right">
        		<p>An experienced Project Manager of <strong>Pinnacle Icons</strong> directing your project is all it takes to drive perfection onboard. Consult your favorite PM today and get started.</p>
        		<a class="secondary-btn-img" href="tel:(312) 517 0979"><img class="col-img" src="assets/images/call-icon.png">(312) 517 0979</a>
        	</div>        	
        </div>
  </div>
</section>
<!-- ======= End FAQ Area ======= -->




<!-- CTA Section Begin -->
  
  <!-- <section class="cta_Sec_main padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-8">
          <div class="cta_content">
            <h3>Consult with our Website Expert</h3>
            <h4>to find the <span>best solution!</span></h4>
          </div>
        </div>

        <div class="col-sm-4">
          <div class="cta_btn">
            <ul>
              <li><a href="#">Talk to our Expert</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section> -->

<!-- CTA Section End -->


<!-- Portfolio Section Begin -->
  
    <section class="portfolio_Sec_main padding_70">
      <div class="container">
        <div class="row">
          <div class="col-12">
            <div class="portfolio_heading">
              <div class="row">
                <div class="col-12 col-lg-8 left-col">
                  <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">We Build Website<br> For All <b>Industry</b> Sectors.</h2>
                  <p class="wow fadeIn" data-wow-duration=".6s" data-wow-delay=".5s">
                    Our clients describe us as a product team which creates amazing UI/UX experiences, by crafting top-notch user experience, logo designs.
                  </p>
                </div>
                <div class="col-12 col-lg-4 right-col">
                  <h3 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Let's Discuss Your Project With Us.</h3>
                  <a class="secondary-btn-img" href="tel:(312) 517 0979"><img class="col-img" src="assets/images/call-icon.png">(312) 517 0979</a>
                  <img class="col-img" src="assets/images/announcement-img.png">
             	  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="tab_portfolio">
              <ul class="nav nav-tabs">

                <li class="nav-item">
                  <a class="nav-link active show" data-toggle="tab" href="#Randon-port">Custom Website</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link " data-toggle="tab" href="#Beauty">Beauty</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#Auto">Auto</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#RealEstate">Real Estate</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#ecommerce-port">E-commerce</a>
                </li>
                <!--<li class="nav-item">-->
                <!--  <a class="nav-link" data-toggle="tab" href="#cbd-port">CBD </a>-->
                <!--</li>-->

                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#education-port">Education </a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#fitness-port">Fitness </a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#food-port">Food </a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#health-port">Health </a>
                </li>

                <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#non-profit-port">Non Profit </a>
                </li>

                
              </ul>
            </div>
          </div>
        </div>
      </div>

        <div class="tab-content">

          <div class="tab-pane active" id="Randon-port">
            <div class="container-fluid ">
              <div class="row">

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>


                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                

                

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/randon/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/randon/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane " id="Beauty">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/beauty/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/beauty/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>


          <div class="tab-pane" id="Auto">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/auto/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/auto/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="RealEstate">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/real-estate/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/real-estate/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="ecommerce-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/ecommerce/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/ecommerce/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="cbd-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/cbd/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/cbd/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="education-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/education/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/education/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="fitness-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/fitness/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/fitness/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="food-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/food/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/food/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="health-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/health/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/health/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="tab-pane" id="non-profit-port">
            <div class="container-fluid ">
              <div class="row">
                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-01.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-01.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-02.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-02.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-03.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-03.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-04.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-04.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-05.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-05.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-06.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-06.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-07.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-07.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

                <div class="col-sm-3 p-0">
                  <div class="portfolio_boxes">
                    <a class="black" data-fancybox="port" href="assets/images/portfolio/non-profit/portfolio-img-08.webp">
                        <figure><img src="assets/images/portfolio/non-profit/portfolio-img-08.webp" class="img-fluid" alt=""></figure>
                    </a>
                  </div>
                </div>

              </div>
            </div>
          </div>

          
        </div>
    </section>

<!-- Portfolio Section End -->



<!-- Form Section Begin -->
  
  <section class="form_Sec_main padding_70" >
    <div class="container-fluid p-0" id="form_2">
      <div class="row align-items-center">
        <div class="col-sm-6 p-0">
          <div class="form_sec_left">
            <img src="assets/images/form-banner-two.jpg" class="img-fluid" alt="">
          </div>
        </div>
        <div class="col-sm-6 p-0">
          <div class="form_sec_tab">
            <h4 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Got Urgent Website Develop Request? Let’s Start With A 15% Discount On Your Way!</h4>
            <div class="cta_form">
             <form action="sendmail.php" method="POST" id="my_captcha_form_1">
                
    			
    			<input type="hidden" name="form" value="2">
                <div class="row">
                  <div class="col-md-6">
                    <input type="text" name="name" id="form2_name" class="form-control" placeholder="Your Name" required="">
                  </div>
                  <div class="col-md-6">
                    <input type="text" name="email" id="form2_email" class="form-control" placeholder="Email Address" required="">
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <div class="intl-tel-input separate-dial-code">
                      <div class="flag-container">
                        <div class="selected-flag" title="Unknown">
                          <div class="iti-flag "></div>
                          <div class="selected-dial-code"></div>
                        </div>
                      </div>
                      <input id="phone-country" name="phone" rangelength="[7,12]" type="number" placeholder="Phone Number" required="" class="cta-phone" autocomplete="off">
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12">
                    <textarea name="message" id="form2_message" class="form-control" placeholder="Your Message"></textarea>
                  </div>
                </div>
                
                <br>
                <div id="msg-sec"></div>
                    
                <div class="row">
                  <div class="col-md-12">
                    <div class="btn_form">
                      <button id="submit-btn-secss" class="button_submit_form" type="submit">Send Now</button>
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

<!-- Form Section End -->


<!-- Packages Section Begin -->
  
  <section class="packages_sec_main padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="web_head text-center">
            <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Turn Your Ideas Into Reality With Budget-Friendly Packages</h2>
          </div>
        </div>
      </div>

      <div class="row pt-5">
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 col-sm-6">
                <div class="best-seller">
                    <img src="assets/images/Best-seller.png" class="img-fluid" alt="">
                </div>                
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>Web Economy</h4>
                  <span class="cutprice">$650 Only</span> <span class="h5"><sup>$</sup>199 Only</span>
                  <div class="package-details">
                    <p>Ideal for small business and start Ups</p>
                  </div>
                </div>
                <ul class="pkg-list">
                <li>3 Page Website Design</li>
                                                            <li>1 Banner Design</li>
                                                            <li>Contact/Query Form</li>
                                                            <li>3 Revisions</li>
                                                            <li>Complete W3C Certified HTML Guarantee</li>
                                                            <li>Complete Deployment</li>
                                                            <li>Complete Source Files</li>
                                                            <li>100% Ownership Rights</li>
                                                            <li>100% Approval Assurance</li>
                                                            <li><strong>*** ADD ONS ***</strong></li>
                                                            <li>$50 Per Additional Page</li>
                                                            <li>$50 Per Additional Page</li>
                                                            <li>$250 Payment Integration</li>
                                                            <li>$300 Shopping Cart Integration</li>
                                                            <li>*NO MONTHLY OR ANY HIDDEN FEE*</li>
                </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop"  name="for $199" class="btn-line-fill">Order Now</a>
                </div>

              </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>Web Content
                  </h4>
                  <span class="cutprice">$789 Only</span> <span class="h5"><sup>$</sup>249 Only</span>
                  <div class="package-details">
                    <p>Suitable for Personal and Professional Web Projects</p>
                  </div>
                </div>
                <ul class="pkg-list">
                <li>250 Words per Page</li>
                  <li>Timely Delivery</li>
                  <li>Superior Standard Content</li>
                  <li>Professional Industry Specific Writers</li>
                  <li><strong>Features</strong></li>
                  <li>100% Satisfaction Guarantee</li>
                  <li>100% Money Back Guarantee*</li>
              </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop" name="for $249" class="btn-line-fill">Order Now</a>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>Web Basic
                  </h4>
                  <span class="cutprice">$700 Only</span> <span class="h5"><sup>$</sup>350 Only</span>
                  <div class="package-details">
                    <p>Ideal for small business and start Ups</p>
                  </div>
                </div>
                <ul class="pkg-list">
                  <li>5 Page Responsive Website Design</li>
                    <li>1 Banner Design</li>
                    <li>Contact/Query Form</li>
                    <li>3 Revisions</li>
                    <li>Complete W3C Certified HTML Guarantee</li>
                    <li>Complete Deployment</li>
                    <li>48 Hours Turn Around Time</li>
                    <li>*** Value Added Services ***</li>
                    <li>Complete Source Files</li>
                    <li>100% Ownership Rights</li>
                    <li>100% Approval Assurance</li>
                    <li>100% Money Back Guarantee *</li>
                    <h4>*** ADD ONS ***</h4>
                    <li>$50 Per Additional Page</li>
                    <li>$250 Payment Integration</li>
                    <li>$300 Shopping Cart Integration</li>
                    <li>*NO MONTHLY OR ANY HIDDEN FEE*</li>
                </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop"  name="for $350" class="btn-line-fill">Order Now</a>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>Super Discount Offer</h4>
                  <span class="cutprice">$1599 Only</span> <span class="h5"><sup>$</sup>699 Only</span>
                  <div class="package-details">
                    <p>Branding Solution for E-Com Startups</p>
                  </div>
                </div>

                <ul class="pkg-list">
                <li>Customized Design</li>
                                                            <li>Up-to 100 Products</li>
                                                            <li>Content Management System (CMS)</li>
                                                            <li>Mini Shopping Cart Integration</li>
                                                            <li>Payment Module Integration</li>
                                                            <li>Easy Product Search</li>
                                                            <li>Dedicated designer & developer</li>
                                                            <li>Features</li>
                                                            <li>100% Satisfaction Guarantee</li>
                                                            <li>100% Unique Design Guarantee</li>
                                                            <li>100% Money Back Guarantee*</li>
                </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,4)" name="for $1249" class="btn-line-fill">Order Now</a>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>E-Commerce Professional Package</h4>
                  <span class="cutprice">$1355 Only</span> <span class="h5"><sup>$</sup>5420 Only</span>
                  <div class="package-details">
                  <p>Ideal for small business and start Ups</p>
                  </div>
                </div>

                <ul class="pkg-list">
                <li>Customized Design</li>
                  <li>Up-to 500 Products</li>
                  <li>Content Management System (CMS)</li>
                  <li>Full Shopping Cart Integration</li>
                  <li>Payment Module Integration</li>
                  <li>Easy Product Search</li>
                  <li>Product Reviews</li>
                  <li>5 Promotional Banners</li>
                  <li>Team of Expert Designers & Developers</li>
                  <li>Features</li>
                  <li>Unlimited Revisions</li>
                  <li>100% Satisfaction Guarantee</li>
                  <li>100% Unique Design Guarantee</li>
                  <li>100% Money Back Guarantee*</li>
                </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,5)" name="for $3294" class="btn-line-fill">Order Now</a>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>
                  E-Commerce Elite</h4>
                  <span class="cutprice">$4220 Only</span> <span class="h5"><sup>$</sup>3555 Only</span>
                  <div class="package-details">
                    <p>Complete branding solution for established ecommerce
                    businesses</p>
                  </div>
                </div>

                <ul class="pkg-list">
                                                             <li>UNLIMITED Logo Design Concepts</li>
                                                            <li>By 6 Award Winning Designers</li>
                                                            <li>Icon Design</li>
                                                            <li>UNLIMITED Revisions</li>
                                                            <li>Print Media</li>
                                                            <li>Stationery Design (BusinessCard,Letterhead &
                                                                Envelope)</li>
                                                            <li>Invoice Design, Email Signature</li>
                                                            <li>Bi-Fold Brochure (OR) 2 Sided Flyer Design</li>
                                                            <li>Product Catalog Design</li>
                                                            <li>Sign age Design (OR) Label Design</li>
                                                            <li>T-Shirt Design (OR) Car Wrap Design</li>
                                                            <li>Website</li>
                                                            <li>E-Commerce Store Design</li>
                                                            <li>Product Detail Page Design</li>
                                                            <li>Unique Banner Slider</li>
                                                            <li>Featured Products Showcase</li>
                                                            <li>Full Shopping Cart Integration</li>
                                                            <li>Unlimited Products</li>
                                                            <li>Unlimited Categories</li>
                                                            <li>Product Rating & Reviews</li>
                                                            <li>Easy Product Search</li>
                                                            <li>Multi-currency SupportPayment Gateway Integration
                                                            </li>
                                                            <li>Multi-currency Support</li>
                                                            <li>Content Management System</li>
                                                            <li>Cutomer Log-in Area</li>
                                                            <li>Mobile Responsive</li>
                                                            <li>Social Media Plugins Integration</li>
                                                            <li>Tell a Friend Feature</li>
                                                            <li>Social Media Pages</li>
                                                            <li>Facebook , Twitter, YouTube, Google+ & Pinterest
                                                                Page Designs</li>
                                                            <li>Value Added Services</li>
                                                            <li>Dedicated Account Manager</li>
                                                            <li>Features</li>
                                                            <li>Unlimited Revisions</li>
                                                            <li>All Final File Formats</li>
                                                            <li>100% Ownership Rights</li>
                                                            <li>100% Unique Design Guarantee</li>
                                                            <li>100% Money Back Guarantee*</li>
                </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,6)" name="for $4999" class="btn-line-fill">Order Now</a>
                </div>
              </div>
            </div>
            
            
            
          </div>
      </div>

    </div>
  </section>

<!-- Packages Section End -->


<!-- What Sets Us Part Begin -->
    
    <section class="what_Sets_Sec padding_70">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <div class="web_head text-left">
              <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Website Builder Company With Blazing Aesthetics.</h2>
              <p class="wow fadeInUp" data-wow-duration=".6s" data-wow-delay=".5s">We don’t only let you witness triple-digit growth but mold your website business plan in a way that suits every business budget out there, from startups to enterprises.</p>
            </div>

            <div class="aprat_Sec_main wow fadeIn" data-wow-duration=".6s" data-wow-delay=".6s">
              <h4>100% Money-Back   <span>Guarantee</span></h4>
              <p>Could it be any better? A holistic guarantee of refund even when only field professionals are on duty. It gets better with Pinnacle Icons every time.</p>
            </div>

            <div class="aprat_Sec_main wow fadeIn" data-wow-duration=".6s" data-wow-delay=".7s">
              <h4>Radical Price   <span>Cap</span></h4>
              <p>Not to toot our own horn, but we have generated numerous custom price packages for our website services that can be affordable for any business out there.</p>
            </div>

            <div class="aprat_Sec_main wow fadeIn" data-wow-duration=".6s" data-wow-delay=".8s">
              <h4>Revision <span>Possibility</span></h4>
              <p>Don’t like what you see? Get it changed to your perspective! We love it when our customers share feedback and mold the designs to their liking.</p>
            </div>

          </div>

          <div class="col-sm-5">
            <div class="set_right_img">
              <img src="assets/images/set-part-img-01.png" class="" alt="">
            </div>
          </div>

        </div>
      </div>
    </section>

<!-- What Sets Us Part End -->


<!-- Industries Section Begin -->
  
  <section class="industry_sec_tab padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="web_head text-center">
            <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Pinnacle Icons Serves To A Plethora Of Industries</h2>
            <p class="wow fadeInUp" data-wow-duration=".6s" data-wow-delay=".5s">Experts never limit their expertise, and Pinnacle Icons finds it exciting to serve different industries. Every business requires a custom web design that complements the industry grounds and adds their personal ideology. Find your industry sector, and let’s build a website for you.</p>
          </div>
        </div>
      </div>

      <div class="row pt-5">
        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".3s">
            <img src="assets/images/industries-icon1.png" class="img-fluid" alt="">
            <h3>Beauty</h3>
            <a data-toggle="modal" data-target="#started_pop">Learn More</a>
          </div>
        </div>
        
        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".3s">
            <img src="assets/images/industries-icon2.png" class="img-fluid" alt="">
            <h3>Automotive</h3>
            <a data-toggle="modal" data-target="#started_pop">Learn More</a>
          </div>
        </div>
        
        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".3s">
            <img src="assets/images/industries-icon3.png" class="img-fluid" alt="">
            <h3>Banking</h3>
            <a data-toggle="modal" data-target="#started_pop">Learn More</a>
          </div>
        </div>
        
        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".3s">
            <img src="assets/images/industries-icon4.png" class="img-fluid" alt="">
            <h3>Digital Agency</h3>
            <a data-toggle="modal" data-target="#started_pop">Learn More</a>
          </div>
        </div>
        
        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".3s">
            <img src="assets/images/industries-icon5.png" class="img-fluid" alt="">
            <h3>Healthcare</h3>
            <a data-toggle="modal" data-target="#started_pop">Learn More</a>
          </div>
        </div>
        
        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".3s">
            <img src="assets/images/industries-icon6.png" class="img-fluid" alt="">
            <h3>Hotel</h3>
            <a data-toggle="modal" data-target="#started_pop">Learn More</a>
          </div>
        </div>
        
        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".3s">
            <img src="assets/images/industries-icon7.png" class="img-fluid" alt="">
            <h3>Logistics</h3>
            <a data-toggle="modal" data-target="#started_pop">Learn More</a>
          </div>
        </div>
        
        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".3s">
            <img src="assets/images/industries-icon8.png" class="img-fluid" alt="">
            <h3>E-Commerce</h3>
            <a data-toggle="modal" data-target="#started_pop">Learn More</a>
          </div>
        </div>
        


    </div>
  </section>

<!-- Industries Section End -->



<!-- Custom Website Design Section Begin -->
  
  <section class="custom_web padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="web_head text-center">
            <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Serving A Series Of Web Necessities To Enhance Operations. </h2>
          </div>
        </div>
      </div>

      <div class="row pt-5">
        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".4s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-1.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>Shopify Website</h4>
              <p>Our Shopify builder will communicate your business values to your narrowed target audience with all the Shopify integrations necessary for your brand to prosper.</p>
            </div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".5s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-2.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>WordPress Website</h4>
              <p>Our WordPress website developer will add all the necessary and add-on functionalities to take your business to the next level and witness ideal conversions. </p>
            </div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".6s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-3.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>Ecommerce Website</h4>
              <p>Let’s get your thriving eCommerce store in development with an exciting eCommerce website and e-shop solutions to make the most out of your sales. </p>
            </div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".7s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-4.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>Informative Website</h4>
              <p>An aesthetic informative website builder is all your need to share your expertise, achievements, and much more to make a difference in the world.</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>

<!-- Custom Website Design Section End -->

<!-- Cilent Review Section Begin -->
  
<section class="main-testi" data-aos="fade-down" data-aos-duration="1500">
  <div class="container">
      <div class="rev-content-container heading">
            <h2>EVERY PROJECT COUNTS </h2>
            <h3>Our Most-Recent <span>Clientele Tale</span> </h3>
      </div>
      <div class="row justify-content-between align-items-center">
        <div class="col-lg-12 col-md-12 p-lg-0">
          <div class="testi-slider owl-carousel owl-theme">
            <div class="item">
                <div class="review_sec_tab">
                            <div class="review_content">
                              <p>I got tired of trying to develop a website myself and reached out to Adam with Pinnacle Icons for assistance. He listened to what I was trying to do and to the exclusive group I was trying to reach. Within a week I had the rough draft of my new website for review—flawless design and engagement.</p>
                            </div>
                            <div class="review_author">
                              <div class="author_name">
                                <h3>Glenn</h3>
                                <div class="rating_sec">
                                  <ul>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                  </ul>
                                </div>
                              </div>
                              <div class="trustpilot-logo">
                                <img src="assets/images/trust_logo.png" class="img-fluid" alt="">
                              </div>
                
                            </div>
                
                          </div>
                    </div>
            <div class="item">
                <div class="review_sec_tab">
                            <div class="review_content">
                              <p>Been looking for someone to help me design my website for healthcare and Pinnacle Icons came just in time to complete my project. Adam really did deliver what he promised. Completed my project and had my website running in 2 weeks or less. Excellent job, no doubt. Simple, very honest, quick and really I got Adam is the one who worked on my project.</p>
                            </div>
                            <div class="review_author">
                              <div class="author_name">
                                <h3>Gina De Carlo</h3>
                                <div class="rating_sec">
                                  <ul>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                  </ul>
                                </div>
                              </div>
                              <div class="trustpilot-logo">
                                <img src="assets/images/trust_logo.png" class="img-fluid" alt="">
                              </div>
                
                            </div>
                
                          </div>
            </div>
            
            <div class="item">
                <div class="review_sec_tab">
                            <div class="review_content">
                              <p>My name is Arom Bates from King and Queen Radio in New York City. I have to say Mr. Adam Fisher has been amazing in his customer service support working with myself and the owner!!! He gets the job done very quickly and is very professional at his job!!!! I look forward to working with Adam Fisher for many years!!!!</p>
                            </div>
                            <div class="review_author">
                              <div class="author_name">
                                <h3>Arom Bates</h3>
                                <div class="rating_sec">
                                  <ul>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                  </ul>
                                </div>
                              </div>
                              <div class="trustpilot-logo">
                                <img src="assets/images/trust_logo.png" class="img-fluid" alt="">
                              </div>
                
                            </div>
                
                          </div>
            </div>
                      
            <div class="item">
                <div class="review_sec_tab">
                            <div class="review_content">
                              <p>Pinnacle Icons is an amazing company with a super friendly staff. I worked with Adam Fisher and he did an amazing job revamping my site. Whenever I reached out to him he responded right away and he understood the assignment! He provided me with excellent customer service and helped me figure a look and feel that would be conducive to my clientele. I am completely satisfied with the final results of my new website! Thanks again Pinnacle Icons!! I will see you guys again for any updates I may need.</p>
                            </div>
                            <div class="review_author">
                              <div class="author_name">
                                <h3>Tanya Tankou</h3>
                                <div class="rating_sec">
                                  <ul>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                  </ul>
                                </div>
                              </div>
                              <div class="trustpilot-logo">
                                <img src="assets/images/trust_logo.png" class="img-fluid" alt="">
                              </div>
                
                            </div>
                
                          </div>
            </div>
            <div class="item">
                <div class="review_sec_tab">
                            <div class="review_content">
                              <p>Adam Fisher created a web page for my business. The experience was very positive. He is a very good professional. He detailed each step that he followed from the beginning until the page was completed. I am very grateful for everything he did.</p>
                            </div>
                            <div class="review_author">
                              <div class="author_name">
                                <h3>Eduardo</h3>
                                <div class="rating_sec">
                                  <ul>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                  </ul>
                                </div>
                              </div>
                              <div class="trustpilot-logo">
                                <img src="assets/images/trust_logo.png" class="img-fluid" alt="">
                              </div>
                
                            </div>
                
                          </div>
            </div>
            <div class="item">
                <div class="review_sec_tab">
                            <div class="review_content">
                              <p>My site was designed by Adam through GDS Pinnacle Icons. They are promoting my site through social media. And overall it has been a really easy and quick process and also a good service. I highly recommend them. Thank you again Adam!</p>
                            </div>
                            <div class="review_author">
                              <div class="author_name">
                                <h3>Yala Williams</h3>
                                <div class="rating_sec">
                                  <ul>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                                  </ul>
                                </div>
                              </div>
                              <div class="trustpilot-logo">
                                <img src="assets/images/trust_logo.png" class="img-fluid" alt="">
                              </div>
                
                            </div>
                
                          </div>
            </div>
          </div>
        </div>
      </div>
  </div>
</section>
<!-- Cilent Review Section End -->

<?php include 'includes/footer.php';?>
