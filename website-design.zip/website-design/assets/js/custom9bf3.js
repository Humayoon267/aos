function openNav() {
    document.getElementById("mySidenav").style.left = "0px";
}
function closeNav() {
    document.getElementById("mySidenav").style.left = "-250px";
}
// END: RESPONSIVE NAVBAR 

// $(function() {
//     var myLazyLoad = new LazyLoad({
//         elements_selector: ".lazy"
//             // load_delay: 300 //adjust according to use case
//     });
// });

// WOW ANIMATION

  new WOW().init();

// WOW ANIMATION

// const cursor = document.querySelector('.cursor');
// document.addEventListener('mousemove', e => {
//     cursor.setAttribute("style", "top: "+(e.pageY - 15)+"px; left: "+(e.pageX - 15)+"px;")
// });

var form_num = 1;

function Nextfun(){
    if(form_num === 1){
        $('#backbtn').show();
        $('#form2').siblings().hide();
        $('#form2').show();
        $('#changetopic').text('What are your website needs?');
        window.location.hash='#website-needs';
        ++form_num;
    }else if(form_num === 2){
        $('#form3').siblings().hide();
        $('#form3').show();
        $('#changetopic').text('What type of business is this for?');
        window.location.hash='#type-of-business';
        ++form_num;
    }else if(form_num === 3){
        $('#form4').siblings().hide();
        $('#form4').show();
        $('#changetopic').text('What industry do you operate in?');
        window.location.hash='#industry-you-operate';
        ++form_num;
    }else if(form_num === 4){
        $('#form5').siblings().hide();
        $('#form5').show();
        $('#changetopic').text('What is your estimated budget for this project?');
        window.location.hash='#estimated-budget';
        ++form_num;
    }else if(form_num === 5){
        $('#form6').siblings().hide();
        $('#form6').show();
        $('#nextbtn').hide();
        $('#backbtn').hide();
        $('#changetopic').text("Great - we've got pros ready and available.");
        $('.holder').addClass('center-txt');
        window.location.hash='#FREE-QUOTE';
        ++form_num;
    }  
}

function Backfun(){
    if(form_num === 2){
        $('#backbtn').hide();
        $('#form1').siblings().hide();
        $('#form1').show();
        $('#changetopic').text('What type of business is this for?');
        --form_num;
    }else if(form_num === 3){
        $('#form2').siblings().hide();
        $('#form2').show();
        $('#changetopic').text('What industry do you operate in?');
        --form_num;
    }else if(form_num === 4){
        $('#form3').siblings().hide();
        $('#form3').show();
        $('#changetopic').text('What industry do you operate in?');
        --form_num;
    }else if(form_num === 5){
        $('#form4').siblings().hide();
        $('#form4').show();
        $('#changetopic').text('What is your estimated budget for this project?');
        --form_num;
    } 
}



$('.banner_slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    fade: true,
    autoplaySpeed: 3000,
    speed: 3500,
    arrows: false,
    dots: false,
    centerPadding: '0px',
    focusOnSelect: true,
    responsive: [
      {
        breakpoint: 580,
          settings: {
          slidesToShow: 1,
          arrows: false,
          dots: false,
          slidesToScroll: 1,
        }
      },

      {
        breakpoint: 992,
          settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        }
      },

      {
        breakpoint: 830,
          settings: {
          slidesToShow: 1,
          arrows: false,
          slidesToScroll: 1,
        }
      },
    ]
  });



$('.situation_box_slider').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    fade: false,
    autoplaySpeed: 3000,
    speed: 2000,
    arrows: true,
    dots: false,
    centerPadding: '0px',
    focusOnSelect: true,
    responsive: [
      {
        breakpoint: 580,
          settings: {
          slidesToShow: 1,
          arrows: false,
          dots: false,
          slidesToScroll: 1,
        }
      },

      {
        breakpoint: 992,
          settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        }
      },

      {
        breakpoint: 830,
          settings: {
          slidesToShow: 1,
          arrows: false,
          slidesToScroll: 1,
        }
      },
    ]
  });


// $('.industries_box_slider').slick({
//     slidesToShow: 1,
//     slidesToScroll: 1,
//     autoplay: true,
//     fade: false,
//     autoplaySpeed: 3000,
//     speed: 2000,
//     arrows: true,
//     dots: false,
//     centerPadding: '0px',
//     focusOnSelect: true,
//     responsive: [
//       {
//         breakpoint: 580,
//           settings: {
//           slidesToShow: 1,
//           arrows: false,
//           dots: false,
//           slidesToScroll: 1,
//         }
//       },

//       {
//         breakpoint: 992,
//           settings: {
//           slidesToShow: 1,
//           slidesToScroll: 1,
//         }
//       },

//       {
//         breakpoint: 830,
//           settings: {
//           slidesToShow: 1,
//           arrows: false,
//           slidesToScroll: 1,
//         }
//       },
//     ]
//   });




   


//=========== FLOATING FORM STARTS
  $(".clickbutton").click(function(){
   $('.floatbutton').toggleClass("active");
   //$('.crossplus').toggleClass("rotate");
});
//=========== FLOATING FORM ENDS

function order_now_value(objButton, packid=1){
    x = objButton.name;
    $('#packages').val($('#packages').find('[pack="'+packid+'"]').attr('value'));
    try{
        document.getElementById('lead_area_popup1').value = x;
        document.getElementById('lead_text').innerHTML = x;
    }catch(ex){}
}


 // intel Tel Input
let ip; 
let ip_value;
 $("#phone-country,#phone-coun,#phone-order").intlTelInput({
     
      allowDropdown: false,
      // autoHideDialCode: false,
      // autoPlaceholder: "off",
      // dropdownContainer: "body",
      // excludeCountries: ["us"],
      // formatOnDisplay: false,
    geoIpLookup: function(callback) {
            $.get('https://ipinfo.io', function() {}, "jsonp").always(function(resp) {
              var countryCode = (resp && resp.country) ? resp.country : "";
              callback(countryCode);
              ip=resp.ip;
            
              
            });
          },
       initialCountry: "auto",
       nationalMode: true,
       separateDialCode: true,
      // onlyCountries: ['us', 'gb', 'ch', 'ca', 'do'],
      // placeholderNumberType: "MOBILE",
      // preferredCountries: ['cn', 'jp'],
     // utilsScript: "<?php echo $basesurl;?>js/utils.js"
    });

setTimeout(function(){
    $('input[name="pc"]').val($('.selected-dial-code').text());
    $('input[name="cip"]').val(ip);
    $('input[name="ctry"]').val( $('.country-list .country.active .country-name').text());
}, 3000);


$('body').delegate('.country','click',function(){
$('input[name="pc"]').val($(this).find('.dial-code').text());
$('input[name="cip"]').val(ip);
$('input[name="ctry"]').val($(this).closest("form").find('.country-list .country.active .country-name').text());

/*var oldString2=$('.selected-flag').attr('title').toUpperCase();
  var newString12 = oldString2.split(':',1)[0];
               $('input[name="ctry"]').val(newString12);*/
 });






 if($(window).innerWidth() <= 751) {
  $('.portfolio_slid').slick({
       dots: true,
       infinite: true,
       autoplay:true,
       speed: 300,
       arrows:false,
       slidesToShow: 1,
       adaptiveHeight: true
    });
 }





// document.onkeydown = function(e) {
//   if(event.keyCode == 123) {
//      return false;
//   }
//   if(e.ctrlKey && e.shiftKey && e.keyCode == 'I'.charCodeAt(0)) {
//      return false;
//   }
//   if(e.ctrlKey && e.shiftKey && e.keyCode == 'C'.charCodeAt(0)) {
//      return false;
//   }
//   if(e.ctrlKey && e.shiftKey && e.keyCode == 'J'.charCodeAt(0)) {
//      return false;
//   }
//   if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) {
//      return false;
//   }
// }


// $(document).on({
//     "contextmenu": function(e) {
//         console.log("ctx menu button:", e.which); 

//         // Stop the context menu
//         e.preventDefault();
//     },
//     "mousedown": function(e) { 
//         console.log("normal mouse down:", e.which); 
//     },
//     "mouseup": function(e) { 
//         console.log("normal mouse up:", e.which); 
//     }
// });

