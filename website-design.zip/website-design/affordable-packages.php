<?php include 'includes/header.php';?>
<!-- Banner Section Begin -->  
    <section class="banner_Sec_main">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-5">
            <div class="banner_content_sec">
              <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Get Custom Tailored Package For Your Business <span>Plan.</span></h2>

            
              <div class="banner-btn wow fadeIn" data-wow-duration=".6s" data-wow-delay=".8s">
                <ul>
                  <li><a data-toggle="modal" data-target="#started_pop">Get Custom Quote</a></li>
                  <li class="chng_clr"><a href="javascript:;" onclick="$zopim.livechat.window.toggle()">Schedule a Call </a></li>
                </ul>
              </div>

              <div class="banner_vector">
                <ul>
                  <li><a href="#" class="wow zoomIn" data-wow-duration=".6s" data-wow-delay=".7s"><img src="assets/images/trust_logo.png"></a></li>
                  <li><a href="#" class="wow zoomIn" data-wow-duration=".6s" data-wow-delay=".8s"><img src="assets/images/topdigi.png"></a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-sm-7">
            <div class="banner_right_img banner_slider">
              <div class="banner_img_tab">
                <img src="assets/images/inner-bnr3.png" class="img-fluid" alt="">
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>

<!-- Banner Section End -->

<!-- Packages Section Begin -->
  
  <section class="packages_sec_main padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="web_head text-center">
            <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Build Website At Pocket-Friendly Rates With Personalized Packages
</h2>
          </div>
        </div>
      </div>

      <div class="row pt-5">
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>Basic Package</h4>
                  <span class="cutprice">$794.00 Only</span> <span class="h5"><sup>$</sup>199.00 Only</span>
                  <div class="package-details">
                    <p>Suitable for potential super-startups and brand revamps for companies.</p>
                  </div>
                </div>
                <ul class="pkg-list">
                  <li>3 Page Website</li>
                  <li>2 Stock Images</li>
                  <li>1 jQuery Slider Banner</li>
                  <li>Contact/Query Form</li>
                  <li>48 to 72 hours TAT</li>
                  <li>Complete Deployment</li>
                  <li>100% Satisfaction Guarantee</li>
                  <li>100% Unique Design Guarantee</li>
                  <li>100% Money Back Guarantee *</li>
                </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,1)" name="for $199" class="btn-line-fill">Order Now</a>
                </div>

              </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>Startup Package</h4>
                  <span class="cutprice">$1294.00 Only</span> <span class="h5"><sup>$</sup>349.00 Only</span>
                  <div class="package-details">
                    <p>Suitable for potential super-startups and brand revamps for companies.</p>
                  </div>
                </div>
                <ul class="pkg-list">
                  <li>5 Page Website</li>
                  <li>5 Stock Photos</li>
                  <li>3 Banner Design</li>
                  <li>1 jQuery Slider Banner</li>
                  <li>FREE Google Friendly Sitemap</li>
                  <li>Complete W3C Certified HTML</li>
                  <li>48 to 72 hours TAT</li>
                  <li>100% Satisfaction Guarantee</li>
                  <li>100% Unique Design Guarantee</li>
                  <li>100% Money Back Guarantee *</li>
                  <li>Mobile Responsive will be Additional $200*</li>
                  <li>CMS will be Additional $250*</li>
              </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,2)" name="for $349" class="btn-line-fill">Order Now</a>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>Professional Package</h4>
                  <span class="cutprice">$1694.00 Only</span> <span class="h5"><sup>$</sup>649.00 Only</span>
                  <div class="package-details">
                    <p>Suitable for potential super-startups and brand revamps for companies.</p>
                  </div>
                </div>
                <ul class="pkg-list">
                  <li> 10 Unique Pages Website</li>
                  <li> CMS / Admin Panel Support</li>
                  <li> 8 Stock images</li>
                  <li> 5 Banner Designs</li>
                  <li> Mobile Responsive</li>
                  <li> 1 jQuery Slider Banner</li>
                  <li> FREE Google Friendly Sitemap</li>
                  <li> Complete W3C Certified HTML</li>
                  <li> 48 to 72 hours TAT</li>
                  <li> Complete Deployment</li>
                  <li> 100% Satisfaction Guarantee</li>
                  <li> 100% Unique Design Guarantee</li>
                  <li> 100% Money Back Guarantee *</li>
                </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,3)" name="for $649" class="btn-line-fill">Order Now</a>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>Elite Package</h4>
                  <span class="cutprice">$2594.00 Only</span> <span class="h5"><sup>$</sup>1249.00 Only</span>
                  <div class="package-details">
                    <p>Suitable for potential super-startups and brand revamps for companies.</p>
                  </div>
                </div>

                <ul class="pkg-list">
                    <li>Upto 15 Unique Pages Website</li>
                    <li>Conceptual and Dynamic Website</li>
                    <li>Mobile Responsive</li>
                    <li>Online Reservation/Appointment Tool (Optional)</li>
                    <li>Online Payment Integration (Optional)</li>
                    <li>Custom Forms</li>
                    <li>Lead Capturing Forms (Optional)</li>
                    <li>Striking Hover Effects</li>
                    <li>Newsletter Subscription (Optional)</li>
                    <li>Newsfeed Integration</li>
                    <li>Social Media Integration</li>
                    <li>Search Engine Submission</li>
                    <li>5 Stock Photos</li>
                    <li>3 Unique Banner Design</li>
                    <li>1 jQuery Slider Banner</li>
                    <li> Complete W3C Certified HTML</li>
                    <li>48 to 72 hours TAT</li>
                    <li>Complete Deployment</li>
                    <li>100% Satisfaction Guarantee</li>
                    <li>100% Unique Design Guarantee</li>
                    <li>100% Money Back Guarantee *</li>
                </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,4)" name="for $1249" class="btn-line-fill">Order Now</a>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>Corporate Package</h4>
                  <span class="cutprice">$3294.00 Only</span> <span class="h5"><sup>$</sup>1949.00 Only</span>
                  <div class="package-details">
                    <p>Suitable for potential super-startups and brand revamps for companies.</p>
                  </div>
                </div>

                <ul class="pkg-list">
                  <li>15 to 20 Pages Website</li>
                  <li>Custom Made, Interactive, Dynamic &amp; High End Design</li>
                  <li>Custom WP (or) Custom PHP Development</li>
                  <li>1 jQuery Slider Banner</li>
                  <li>Up to 10 Custom Made Banner Designs</li>
                  <li>10 Stock Images</li>
                  <li>Unlimited Revisions</li>
                  <li>Special Hoover Effects</li>
                  <li>Content Management System (CMS)</li>
                  <li>Online Appointment/Scheduling/Online Ordering Integration (Optional)</li>
                  <li>Online Payment Integration (Optional)</li>
                  <li>Multi Lingual (Optional)</li>
                  <li>Custom Dynamic Forms (Optional)</li>
                  <li>Signup Area (For Newsletters, Offers etc.)</li>
                  <li>Search Bar</li>
                  <li>Live Feeds of Social Networks integration (Optional)</li>
                  <li>Mobile Responsive</li>
                  <li>FREE 5 Years Domain Name</li>
                  <li>Free Google Friendly Sitemap</li>
                  <li>Search Engine Submission</li>
                  <li>Complete W3C Certified HTML</li>
                  <li>Industry Specified Team of Expert Designers and Developers</li>
                  <li>Complete Deployment</li>
                  <li>Dedicated Accounts Manager</li>
                  <li>100% Ownership Rights</li>
                  <li>100% Satisfaction Guarantee</li>
                  <li>100% Unique Design Guarantee</li>
                  <li>100% Money Back Guarantee *</li>
                </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,5)" name="for $3294" class="btn-line-fill">Order Now</a>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>Business Package</h4>
                  <span class="cutprice">$4999.00 Only</span> <span class="h5"><sup>$</sup>3294.00 Only</span>
                  <div class="package-details">
                    <p>Suitable for potential super-startups and brand revamps for companies.</p>
                  </div>
                </div>

                <ul class="pkg-list">
                  <li>15 to 20 Pages Website</li>
                  <li>15 Seconds 2D Explainer Video</li>
                  <li>Voice - Over &amp; Sound Effects</li>
                  <li>Professional Script Writing</li>
                  <li>Storyboard</li>
                  <li>SEO Meta Tags</li>
                  <li>Custom Made, Interactive, Dynamic &amp; High End Design</li>
                  <li>Custom WP (or) Custom PHP Development</li>
                  <li>1 jQuery Slider Banner</li>
                  <li>Up to 10 Custom Made Banner Designs</li>
                  <li>10 Stock Images</li>
                  <li>Unlimited Revisions</li>
                  <li>Special Hoover Effects</li>
                  <li>Content Management System (CMS)</li>
                  <li>Online Appointment/Scheduling/Online Ordering Integration (Optional)</li>
                  <li>Online Payment Integration (Optional)</li>
                  <li>Multi Lingual (Optional)</li>
                  <li>Custom Dynamic Forms (Optional)</li>
                  <li>Signup Area (For Newsletters, Offers etc.)</li>
                  <li>Search Bar</li>
                  <li>Live Feeds of Social Networks integration (Optional)</li>
                  <li>Mobile Responsive</li>
                  <li>FREE 5 Years Domain Name</li>
                  <li>Free Google Friendly Sitemap</li>
                  <li>Search Engine Submission</li>
                  <li>Complete W3C Certified HTML</li>
                  <li>Industry Specified Team of Expert Designers and Developers</li>
                  <li>Complete Deployment</li>
                  <li>Dedicated Accounts Manager</li>
                  <li>100% Ownership Rights</li>
                  <li>100% Satisfaction Guarantee</li>
                  <li>100% Unique Design Guarantee</li>
                  <li>100% Money Back Guarantee *</li>
                </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,6)" name="for $4999" class="btn-line-fill">Order Now</a>
                </div>
              </div>
            </div>
            
            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>Automated/Interactive Conferencing Portal Package</h4>
                  <span class="cutprice">$13000.00 Only</span> <span class="h5"><sup>$</sup>6999.00 Only</span>
                  <div class="package-details">
                    <p>Suitable for potential super-startups and brand revamps for companies.</p>
                  </div>
                </div>

                <ul class="pkg-list">
                    <li>Upto 20 Stock Images</li>
                    <li>20 Unique Banner Designs</li>
                    <li>Unlimited Page Website</li>
                    <li>Custom Content Management System (CMS)</li>
                    <li>Unique Pages And UI Design</li>
                    <li>Complete Custom Development</li>
                    <li>Process Automation Tools</li>
                    <li>Newsfeed Integration</li>
                    <li>Social Media Plugins Integration</li>
                    <li>JQuery Slider</li>
                    <li>Search Engine Submission</li>
                    <li>Free Google Friendly Sitemap</li>
                    <li>3 Years FREE Hosting</li>
                    <li>Custom Email Addresses</li>
                    <li>Social Media Page Designs (Facebook, Twitter, Instagram)</li>
                    <li>Complete W3C Certified HTML</li>
                    <li>Complete Deployment 100%</li>
                    <li>Automated Course Creation</li>
                    <li>Video Conferencing</li>
                    <li>Skills/Certification Tracking</li>
                    <li>Mobile Learning</li>
                    <li>Asynchronous Learning</li>
                    <li>CRM Features</li>
                    <li>Gamification</li>
                    <li>Social Learning/Message Boards</li>
                    <li>Motivational Triggers</li>
                    <li>Forums And Webinars</li>
                    <li>E-commerce And Subscriptions</li>
                    <li>Online Course Booking</li>
                    <li>Excellent Reporting</li>
                    <li>Invoicing Integration</li>
                    <li>Financial Integrations</li>
                    <li>Student Information management</li>
                    <li>Automated communications</li>
                    <li>Learning Management System</li>
                    <li>Quick And Easy Course Scheduling</li>
                    <li>Reporting And Data Analysis</li>
                    <li>Assessment Management & Live Feedback</li>
                    <li>Gradebooks</li>
                    <li>Quick User Integration</li>
                    <li>Easy Payment Methods</li>
                    <li>Online Communities & Social Engagement</li>
                    <li>Curation of Resources And Adding Own Resources</li>
                    <li>Satisfaction Guarantee 100%</li>
                    <li>Unique Design Guarantee 100%</li>
                    <li>Money Back Guarantee *</li>
                </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,7)" name="for $6999" class="btn-line-fill">Order Now</a>
                </div>
              </div>
            </div>
            
            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="package-box">
                <div class="package-top text-center">
                  <h4>Custom CRM/ERP Portal Website Package</h4>
                  <span class="cutprice">$23750.00 Only</span> <span class="h5"><sup>$</sup>14999.00 Only</span>
                  <div class="package-details">
                    <p>Suitable for potential super-startups and brand revamps for companies.</p>
                  </div>
                </div>

                <ul class="pkg-list">
                    <li>Unlimited Page Website</li>
                  <li>Unique Pages and UI Design</li>
                  <li>Complete Custom Development</li>
                  <li>Newsfeed Integration</li>
                  <li>CRM (Customer Relation Management System)</li>
                  <li>Performance and analytics</li>
                  <li>Customization of Personal Details</li>
                  <li>Process management</li>
                  <li>Sales Automation</li>
                  <li>Team Collaboration</li>
                  <li>Marketing Automation</li>
                  <li>Security</li>
                  <li>Integrations</li>
                  <li>Mobile Notifications</li>
                  <li>Sales Reports</li>
                  <li>Trend Analytics</li>
                  <li>Forecasting</li>
                  <li>Territory Management</li>
                  <li>Account Management</li>
                  <li>Event Integration</li>
                  <li>Advanced Data Security</li>
                  <li>Opportunity Management</li>
                  <li>Sales Forecasting</li>
                  <li>Call/Video Logging</li>
                  <li>Quotes</li>
                  <li>Contracts</li>
                  <li>Document Library</li>
                  <li>Case Management</li>
                  <li>Analytics and Dashboards</li>
                  <li>Lead Management</li>
                  <li>Resource Management</li>
                  <li>Analytics</li>
                  <li>Web Intelligence</li>
                  <li>Automated Emails, Invoices &amp; Estimates</li>
                  <li>Automated Split invoicing</li>
                  <li>Automated Combine invoices</li>
                  <li>Invoice templates</li>
                  <li>Financial Reports</li>
                  <li>Generate extremely detailed reports for your sales and services. Filter your reports by date-range and category to see what's making you the most money.</li>
                  <li>Generate automated sales reports</li>
                  <li>Core Modules</li>
                  <li>Human Resources</li>
                  <li>Integration</li>
                  <li>Business Intelligence</li>
                  <li>Sales/Marketing</li>
                  <li>Finance</li>
                  <li>Core Features</li>
                  <li>Reporting</li>
                  <li>Accounting</li>
                  <li>Tracking and Visibility</li>
                  <li>Centralized Modules</li>
                  <li>ERP Database</li>
                  <li>Human Resources Management</li>
                  <li>Business Process Management</li>
                  <li>Enterprise Analytics</li>
                  <li>Business Intelligence</li>
                  <li>Centralized Modules</li>
                  <li>ERP Database</li>
                  <li>Integrations</li>
                  <li>If (Manufacturing) (Optional)</li>
                  <li>Accounting</li>
                  <li>Distribution</li>
                  <li>Business Intelligence</li>
                  <li>Insights</li>
                  <li>Standardization</li>
                  <li>Procurement</li>
                  <li>Reporting and Analytics</li>
                  <li>Forecasting</li>
                  <li>Projection</li>
                  <li>Enterprise-wide integration</li>
                  <li>Real-Time Operations</li>
                  <li>Problem definition</li>
                  <li>Description of the program’s objectives and scope</li>
                  <li>Assumptions</li>
                  <li>Implementation costs</li>
                  <li>Implementation schedule</li>
                  <li>Development and operational risks</li>
                  <li>Projected benefits</li>
                  <li>Team Members</li>
                  <li>Contracts</li>
                  <li>Infrastructure Upgrades</li>
                  <li>Create work plans and timelines</li>
                  <li>Analyze gaps</li>
                  <li>Configure parameters</li>
                  <li>Migrate data</li>
                  <li>Test system</li>
                  <li>Document system</li>
                  <li>Advanced Admin Features 2.0</li>
                  <li>User Signup/Login Functionalities</li>
                  <li>Advanced User Features</li>
                  <li>User Profile Management</li>
                  <li>General Configuration Features</li>
                  <li>Complete W3C Certified HTML</li>
                  <li>Complete Deployment</li>
                  <li>100% Satisfaction Guarantee</li>
                  <li>100% Unique Design Guarantee</li>
                  <li>Money Back Guarantee</li>
                </ul>

                <div class="btn_packages">
                  <a data-toggle="modal" data-target="#order_pop" onclick="order_now_value(this,8)" name="for $6999" class="btn-line-fill">Order Now</a>
                </div>
              </div>
            </div>
          </div>
      </div>

    </div>
  </section>

<!-- Packages Section End -->


<!-- What Sets Us Part Begin -->
    
    <section class="what_Sets_Sec padding_70">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <div class="web_head text-left">
              <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">What Sets Us Apart To Build Website?</h2>
              <p class="wow fadeInUp" data-wow-duration=".6s" data-wow-delay=".5s">We put our passion and creativity into every project we work on. Our procedure is straightforward, and our coordination ensures that all of our work is done with originality and expertise.</p>
            </div>

            <div class="aprat_Sec_main wow fadeIn" data-wow-duration=".6s" data-wow-delay=".6s">
              <h4>Industry  <span>Exposure</span></h4>
              <p>Years of experience offering high-end solutions to a diverse range of businesses. </p>
            </div>

            <div class="aprat_Sec_main wow fadeIn" data-wow-duration=".6s" data-wow-delay=".7s">
              <h4>Client-Oriented  <span>Processes</span></h4>
              <p>We are aware of the current consumer's requirements. We create customer-centric procedures for businesses of all sizes, from small to large.</p>
            </div>

            <div class="aprat_Sec_main wow fadeIn" data-wow-duration=".6s" data-wow-delay=".8s">
              <h4>24/7 Client   <span>Support</span></h4>
              <p>We believe in establishing a relationship with every consumer to whom we offer our services. This aids our staff in comprehending our client's problems and thoughts.</p>
            </div>

          </div>

          <div class="col-sm-5">
            <div class="set_right_img">
              <img src="assets/images/set-part-img-01.png" class="" alt="">
            </div>
          </div>

        </div>
      </div>
    </section>

<!-- What Sets Us Part End -->


<!-- Industries Section Begin -->
  
  <section class="industry_sec_tab padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="web_head text-center">
            <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Our Service expands to a plethora of Industries</h2>
            <p class="wow fadeInUp" data-wow-duration=".6s" data-wow-delay=".5s">The Website Designs  's development team specializes in coming up with innovative solutions for customers in a wide range of industries. Dedicated Website Designer assisting companies in the travel, hotel, education, and healthcare industries, among others...</p>
          </div>
        </div>
      </div>

      <div class="row pt-5">
        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".3s">
            <img src="assets/images/indus-i2.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".4s">
            <img src="assets/images/indus-i.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".5s">
            <img src="assets/images/indus-i2.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".6s">
            <img src="assets/images/indus-i3.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".7s">
            <img src="assets/images/indus-i4.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".8s">
            <img src="assets/images/indus-i5.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay=".9s">
            <img src="assets/images/indus-i6.png" class="img-fluid" alt="">
          </div>
        </div>

        <div class="col-sm-3">
          <div class="industry_box_sec wow zoomIn" data-wow-duration=".6s" data-wow-delay="1s">
            <img src="assets/images/indus-i7.png" class="img-fluid" alt="">
          </div>
        </div>
      </div>

    </div>
  </section>

<!-- Industries Section End -->



<!-- Custom Website Design Section Begin -->
  
  <section class="custom_web padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="web_head text-center">
            <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".3s">Your Business Websites Needs A Custom Website Development To Stand Out. </h2>
          </div>
        </div>
      </div>

      <div class="row pt-5">
        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".4s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-1.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>SEO-Friendly & Responsive</h4>
              <p>What good is a website if no one ever views it? To be visible to your target audience, your website must be responsive and SEO-friendly.</p>
            </div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".5s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-2.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>App Integrations</h4>
              <p>Our incorporated app integrations help retailers save time and money by reducing administrative tasks and boosting user experience and functionality.</p>
            </div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".6s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-3.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>Content Management System</h4>
              <p>Your E-commerce platform's administrator has the authority to alter or add content. The administration interface is more basic and user-friendly.</p>
            </div>
          </div>
        </div>

        <div class="col-sm-3">
          <div class="feathred_box_sec wow bounceIn" data-wow-duration=".6s" data-wow-delay=".7s">
            <div class="feathred_icon_sec">
              <img src="assets/images/choose-icon-4.png" class="img-fluid">
            </div>
            <div class="feathred_box_content">
              <h4>Quick Load Time</h4>
              <p>You can achieve lightning-fast load speeds and provide your customers a terrific online buying experience with Custom Website Development.</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>

<!-- Custom Website Design Section End -->



<!-- Cilent Review Section Begin -->
  
  <section class="review_sec_main padding_70">
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="web_head text-center">
            <h2 class="wow fadeInDown" data-wow-duration=".6s" data-wow-delay=".4s">Why Our Clients Are Happy To Share Reviews?</h2>
          </div>
        </div>
      </div>

      <div class="row pt-5">
        <div class="col-sm-6">
          <div class="review_sec_tab">
            <div class="review_content">
              <p>I had a fantastic time working with the entire The Website Designs   team. They were knowledgeable, competent, and patient with all of our needs. During the building of our website, their procedure was outstanding. The The Website Designs   team provided me with what I requested. Based on my own experience, I highly suggest The Website Designs  .</p>
            </div>

            <div class="review_author">
              <div class="author_name">
                <h3>Allan</h3>
                <div class="rating_sec">
                  <ul>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                  </ul>
                </div>
              </div>

              <div class="trustpilot-logo">
                <img src="assets/images/trust_logo.png" class="img-fluid" alt="">
              </div>

            </div>

          </div>
        </div>
        <div class="col-sm-6">
          <div class="review_sec_tab">
            <div class="review_content">
              <p>The Website Designs  's crew is always quick to respond. They paved the way for my accomplishment. Our website was developed in such a way that it is simple for me to edit. As someone who does not write HTML code, I am confident in my ability to complete many of our website improvements without the need for assistance. But I know that if I ask for assistance, the The Website Designs   team will make it look excellent and quickly.</p>
            </div>

            <div class="review_author">
              <div class="author_name">
                <h3>Robert</h3>
                <div class="rating_sec">
                  <ul>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                    <li><i class="fa fa-star" aria-hidden="true"></i></li>
                  </ul>
                </div>
              </div>

              <div class="trustpilot-logo">
                <img src="assets/images/trust_logo.png" class="img-fluid" alt="">
              </div>

            </div>

          </div>
        </div>
      </div>

    </div>
  </section>

<!-- Cilent Review Section End -->

<?php include 'includes/footer.php';?>
