


<footer>
  <div class="container" id="form_3">
    <div class="row">
      <div class="col-sm-5">
        <div class="footer_logo">
          <h4>Let's Sign-up For the Best Website Experience.</h4>
          <p>At Pinnacle Icons, we’re all about crafting standout design solutions led by a team of experienced professionals. We believe in professionalism, trust, and building strong connections with every client. Your success is our mission.</p>
          <ul>
            <li>
              <span><i class="fa fa-map-marker" aria-hidden="true"></i></span>
              <p>111 W Jackson Blvd Downtown, Suite 1700 Chicago, Illinois, 60604</p>
            </li>

            <li>
              <span><i class="fa fa-envelope" aria-hidden="true"></i></span>
              <a href="mailto:info@pinnacleicons.com">info@pinnacleicons.com</a>
            </li>

            <li>
              <span><i class="fa fa-phone" aria-hidden="true"></i></span>
              <a href="tel:(312) 517 0979">(312) 517 0979</a>
            </li>
          </ul>
        </div>
      </div>

      <div class="col-sm-6 offset-1">
        <div class="footer_form_sec">
          <div class="form_footer_head">
            <h2>REQUEST A CALL BACK</h2>
          </div>
          <form action="sendmail.php" method="POST" >
            
            
			
            <div class="row">
              <div class="col-md-12">
                <input type="text" name="name" id="form3_name" class="form-control" placeholder="Your Name" required="">
              </div>
            </div>

            <div class="row">
              <div class="col-md-12">
                <input type="text" name="email" id="form3_email" class="form-control" placeholder="Email Address" required="">
              </div>
            </div>

            <div class="row">
              <div class="col-md-12">
                <input id="phone-country" name="phone" rangelength="[7,12]" type="number" placeholder="Phone Number" required="" class="cta-phone form3_phone" autocomplete="off">
              </div>
            </div>

            <div class="row">
              <div class="col-md-12">
                <textarea name="message" id="form3_message" class="form-control" placeholder="Your Message"></textarea>
              </div>
            </div>
                
                
            <div class="row">
              <div class="col-md-12">
                <div class="btn_form">
                  	<button id="submit-btn-indexss" class="button_submit_form" type="submit">Send Now</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>

    </div>
  </div>  
  <div class="copy_right">
    <div class="container">
      <div class="row">
        <div class="col-sm-6">
          <div class="copy_right_text">
            <p>Copyrights Pinnacle Icons 2024. All Rights Reserved</p>
          </div>
        </div>
        <div class="col-sm-6">
          <div class="pay_icon">
            <img src="assets/images/pay.png" class="img-fluid" alt="">
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>



<div class="floation">
  
<a href="mailto:info@pinnacleicons.com" class="callusnow now-1"><i class="fa fa-envelope" aria-hidden="true"></i></a>


<a href="tel:(312) 517 0979" class="callusnow usnow-1"><i class="fa fa-phone"></i></a>

</div>

<!-- Lead Form Section Begin -->
<section class="lead_popup">
  <div class="modal fade show" id="myModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <!-- Modal Header -->
        <div class="modal-header"> <button type="button" class="close" id="btnclose" data-dismiss="modal">×</button> </div>
        <!-- Modal body --> 
        <div class="modal-body mb-0 pb-0 mt-0">
          <div class="container ">
            <!-- custom radio button -->
            <div class="holder">
              <div class="row mb-1">
                <div class="col">
                  <h2 id="changetopic">What is your web design requirement?</h2>
                </div>
              </div>
              <form class="CrudForm" id="banform" method="POST" action="../sendmail.php">
                <div class="">
                  <div class="row justify-content-start">
                    <div class="col-12 mar-top-pls" id="form1">
                      <div class="row align-items-center"> 
                        <input type="radio" name="f1" id="q1" value="Create a new website" checked=""> <label for="q1"> Create a new website </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f1" value="Major changes to my website" id="q2"> <label for="q2"> Major changes to my website </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f1" value="Minor changes to my website" id="q3"> <label for="q3"> Minor changes to my website </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f1" value="other1" id="q100"> <label for="q100"> <input type="text" name="other1" id="" class="fm-c form-control" placeholder="Other"> </label> 
                      </div>
                    </div>
                    <div class="col-12 mar-top-pls" id="form2" style="display: none;">
                      <div class="row align-items-center"> 
                        <input type="radio" name="f2" value="To advertise my business/services" id="q4" checked=""> <label for="q4"> To advertise my business/services </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f2" value="To sell products/services e.g. e-commerce" id="q5"> <label for="q5">To sell products/services e.g. e-commerce</label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f2" value="To offer bespoke functionality e.g. logins, forums, CRM" id="q6"> <label for="q6">To offer bespoke functionality e.g. logins, forums, CRM </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f2" id="q7" value="other2"> <label for="q7"><input type="text" name="other2" id="" class="fm-c form-control" placeholder="Other"></label> 
                      </div>
                    </div>
                    <div class="col-12 mar-top-pls" id="form3" style="display: none;">
                      <div class="row align-items-center" > 
                        <input type="radio" name="f3" id="q8" value="Personal project" checked=""> <label for="q8">Personal project</label> 
                      </div>
                      <div class="row align-items-center" > 
                        <input type="radio" name="f3" id="q9" value="Sole trader/self-employed"> <label for="q9">Sole trader/self-employed</label> 
                      </div>
                      <div class="row align-items-center" > 
                        <input type="radio" name="f3" id="q10" value="Small business (1 - 9 employees)"> <label for="q10"> Small business (1 - 9 employees) </label> 
                      </div>
                      <div class="row align-items-center" > 
                        <input type="radio" name="f3" id="q11" value="Medium business (10 - 29 employees)"> <label for="q11"> Medium business (10 - 29 employees) </label> 
                      </div>
                      <div class="row align-items-center" > 
                        <input type="radio" name="f3" id="q12" value="Large business (30 - 99 employees)"> <label for="q12"> Large business (30 - 99 employees) </label> 
                      </div>
                      <div class="row align-items-center" > 
                        <input type="radio" name="f3" id="q13" value="Extra large business (100 or more employees)"> <label for="q13"> Extra large business (100 or more employees) </label> 
                      </div>
                      <div class="row align-items-center" > 
                        <input type="radio" name="f3" id="q14" value="Charity/non-profit"> <label for="q14"> Charity/non-profit </label> 
                      </div>
                      <div class="row align-items-center" > 
                        <input type="radio" name="f3" id="q15" value="other3"> <label for="q15"> <input type="text" name="other3" id="" class="fm-c form-control" placeholder="Other"> </label> 
                      </div>
                    </div>
                    <div class="col-12 mar-top-pls" id="form4" style="display: none;">
                      <div class="row align-items-center"> 
                        <input type="radio" name="f4" id="q16" value="Business services" checked=""> <label for="q16">Business services</label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f4" id="q17" value="Creative industries"> <label for="q17">Creative industries</label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f4" id="q18" value="Entertainment &amp; events"> <label for="q18"> Entertainment &amp; events </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f4" id="q19" value="Financial services"> <label for="q19"> Financial services </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f4" id="q20" value="Health &amp; fitness"> <label for="q20"> Health &amp; fitness </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f4" id="q21" value="Home services"> <label for="q21"> Home services </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f4" id="q22" value="Restaurant/food"> <label for="q22"> Restaurant/food </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f4" id="q23" value="Retail/consumer goods"> <label for="q23"> Retail/consumer goods </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f4" id="q24" value="Technology/software"> <label for="q24"> Technology/software </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f4" id="q25" value="other4"> <label for="q25"> <input type="text" name="other4" id="" class="fm-c form-control" placeholder="Other"> </label> 
                      </div>
                    </div>
                    <div class="col-12 mar-top-pls" id="form5" style="display: none;">
                      <div class="row align-items-center"> 
                        <input type="radio" name="f5" id="q26" value="Less than $500" checked=""> <label for="q26">Less than $500</label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f5" id="q27" value="$500 - $999"> <label for="q27">$500 - $999</label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f5" id="q28" value="$1,000 - $1,999"> <label for="q28"> $1,000 - $1,999 </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f5" id="q29" value="$1,000 - $1,999"> <label for="q29"> $1,000 - $1,999 </label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f5" id="q30" value="$3,000 - $4,999"> <label for="q30"> $3,000 - $4,999 </label>
                      </div>
                      <div class="row align-items-center"> 
                        <input type="radio" name="f5" id="q31" value="$5,000 or more"> <label for="q31"> $5,000 or more </label>
                      </div>
                    </div>
                    <div class="col-12 mar-top-pls" id="form6" style="display: none;">
                      <div class="row align-items-center"> 
                        <input type="text" name="Name" id="32" placeholder="Name" required="" class="form-control formtext"> <label for="32"></label> 
                      </div>
                      <div class="row align-items-center">
                        <input type="email" name="Email" id="33" placeholder="Email" required="" class="form-control formtext"> <label for="33"></label> 
                      </div>
                      <div class="row align-items-center"> 
                        <input id="custom-order" name="Number" rangelength="[7,12]" type="number" placeholder="Phone Number" required="" class="cta-phone" autocomplete="off"> 
                        <label for="34">
                        </label>
                      </div>
                      <div class="row align-items-center"> 
                        <input type="submit" id="submitdata" name="submit" placeholder="Number" class="form-control formtext btn-success">
                        <input type="hidden" name="ctry" value="">
                        <input type="hidden" name="pc" value="">
                        <input type="hidden" name="cip" value="">
                        <input type="hidden" name="hiddencapcha" value="">
                        <input type="hidden" id="location" name="locationURL" value="index.html" />
                        <label for=""></label>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row mt-0 ml-4">
                </div>
                <div class="row mt-4"></div>
              </form>
            </div>
          </div>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer pt-0 mt-0 pb-5 pr-6 m-1 ">
          <div class="col-md-12">
            <div class="modal-btn">
              <ul>
                <li> <button type="button" id="backbtn" onclick="Backfun()" class="btn btn-outline-light modal_footer" style="display: none;">Back</button></li>
                <li> <button type="button" id="nextbtn" onclick="Nextfun()" class="btn btn-success box-shadow--16dp">Next</button></li>
              </ul>
            </div>
          </div>
          <!-- <div class="col-2"> </div>
            <div class="col-5 justify-content-start"></div>
            <div class="col-2 justify-content-end "> -->
          <!-- <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button> --> 
          <button type="button" id="backbtn" onclick="Backfun()" class="btn btn-outline-light modal_footer" style="display: none;">Back</button> 
        </div>
        <!-- <div class="col-3 justify-content-start m-0 p-0"> <button type="button" id="nextbtn" onclick="Nextfun()" class="btn btn-success box-shadow--16dp">Next</button> </div> -->
        <!-- </div> -->
      </div>
    </div>
  </div>
</section>
<!-- Lead Form Section End -->

<!-- Started POPUP Section Begin -->
<section class="started_popup_sec">
  <div class="modal fade" id="started_pop" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">m
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="form_head_Sec">
            <h2>Thanks Giving Discounted Offer</h2>
            <h4>Signup Now</h4>
            <h3>Get upto 70% discount </h3>
          </div>
          <form class="CrudForm" id="banform1">
            <div class="row">
              <div class="col-md-12">
                <input type="text" name="Name" required="" placeholder="Full Name">
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <input type="email" name="Email" required="" placeholder="Email Addresss">
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <input id="phone-coun" name="Number" rangelength="[7,12]" type="number" placeholder="Phone Number" required="" class="cta-phone" autocomplete="off">
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <textarea class="form-control" name="Message" placeholder="Additional Information" required=""></textarea>
              </div>
            </div>
            
            <br>
            <div class="row">
              <div class="col-md-12">
                <div class="btn_form">
                  <input type="submit" value="Submit">
                  <input type="hidden" id="location" name="websiteURL" value="index.html" />
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Started POPUP Section End -->

<!-- Order Form Section Begin -->
<section class="started_popup_sec">
  <div class="modal fade" id="order_pop" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <div class="form_head_Sec">
            <h2>Seal The Limited Time Offer Before It Expires</h2>
            <h4>Get Started</h4>
            <h3>50% Coupon Now</h3>
          </div>
        <form action="sendmail.php" id="banforms" method="POST" >
            <input type="hidden" name="user_ip" value ="<?php echo $_SERVER['REMOTE_ADDR']; ?>" >
           
            <input type="hidden" name="page_link" value ="<?php echo $page_link ?>" >
            <input type="hidden" name="form" value ="1" >
        <div class="row">
              <div class="col-md-12">
                <input type="text" name="name" id="name_pop" required="" placeholder="Full Name">
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <input type="email" name="email" id="email_pop" required="" placeholder="Email Addresss">
              </div>
            </div>
            <!--<div class="row">-->
            <!--  <div class="col-md-12">-->
            <!--    <select name="Package" id="packages" class="valid safari_only" aria-invalid="false">-->
            <!--      <option value="" pack="0">Select Package</option>-->
            <!--      <optgroup label="&nbsp;&nbsp;&nbsp;&nbsp;--------------------------------------------">-->
            <!--        <option value="Basic Web Packages - $199" pack="1">Basic Web Packages - $199</option>-->
            <!--        <option value="Startup Web Packages - $349" pack="2">Startup Web Packages - $349</option>-->
            <!--        <option value="Professional Website Packages - $649" pack="3">Professional Website Packages - $649</option>-->
            <!--        <option value="Elite Website Packages - $1249" pack="4">Elite Website Packages - $1249</option>-->
            <!--        <option value="Corporate Website Packages - $1949" pack="5">Corporate Website Packages - $1949</option>-->
            <!--        <option value="Business Website Packages - $3294" pack="6">Business Website Packages - $3294</option>-->
            <!--        <option value="Automated/Interactive Conferencing Portal Packages - $6999" pack="7">Automated/Interactive Conferencing Portal Packages - $6999</option>-->
            <!--        <option value="Custom CRM/ERP Portal Website Packages - $14999" pack="8">Custom CRM/ERP Portal Website Packages - $14999</option>-->
            <!--      </optgroup>-->
            <!--    </select>-->
            <!--  </div>-->
            <!--</div>-->
            <div class="row">
              <div class="col-md-12">
                <input id="phone-order" name="phone"  rangelength="[7,12]" type="number" placeholder="Phone Number" required="" class="cta-phone" autocomplete="off">
              </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                <textarea class="form-control" id="message_pop" name="message" placeholder="Additional Information" required=""></textarea>
              </div>
            </div>
             <div class="row">
              <div class="col-md-12">
            <div id="msg-modal"></div>
             </div>
            </div>
            <br>
            
            
            <div class="row">
              <div class="col-md-12">
                <div class="btn_form">
                   <button type="submit" class="button_submit_form" id="submit-btn-modals">Send Now</button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- Started POPUP Section End -->
<script src="assets/js/all.js"></script>
<script src="assets/js/lazyload.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
<!-- <script src="https://cdn.userway.org/widgetapp/2021-12-03/widget_app_base_1638570211163.js" async="" id="a11yWidgetSrc"></script> -->
<script src="assets/js/custom9bf3.js?15"></script>
<!--<script src="includes/notifications/notificationscript.js"></script>-->

<script type="text/javascript">
    // zE(function() {
    // zE.activate();
    // });
</script>


<script>
$(".testi-slider").owlCarousel({
    loop: true,
    margin: 30,
    nav:false,
    dots: false,  
    autoplay:true,
    autoplayTimeout:10000,
    autoplayHoverPause:true,
        responsive:{
            0:{
                items:1
            },
            
            575:{
                items:1
            },
            991:{
                items:2
            },
            1024:{
                items:2
            },
            1200: {
                items:2
            }
        }        
    });
$(document).ready(function () {
    setTimeout(function () {
    $(".auto-modal").trigger('click');
}, 60000);
});


// Middle Sec
        $(document).ready(function(){
          $('#submit-btn-sec').click(function(event){
            event.preventDefault();
             $.ajax({
                dataType: 'JSON',
                url: 'sendmail.php',
                type: 'POST',
                data: $('#contact-sec').serialize(),
                beforeSend: function(xhr){
                  $('#submit-btn-sec').html('SENDING...');
                },
                success: function(response){
                  if(response){
                    console.log(response);
                    if(response['isSuccess']){
                    //  $('#msg-sec').html('<div class="alert alert-success">'+ response['msg']  +'</div>');
                      $('input, textarea').val(function() {
                         return this.defaultValue;
                      });
                      window.location.href = "https://pinnacleicons.com/lp/website-design/thankyou.php";
                    }
                    else{
                      $('#msg-sec').html('<div class="alert alert-danger">'+ response['msg'] +'</div>');
                    }
                  }
                },
                error: function(){
                  $('#msg-sec').html('<div class="alert alert-danger">Errors occur. Please try again later.</div>');
                },
                complete: function(){
                  $('#submit-btn-sec').html('SUBMIT');
                }
              });
          });
        });

// Home Page
        $(document).ready(function(){
          $('#submit-btn-index').click(function(event){
            event.preventDefault();
             $.ajax({
                dataType: 'JSON',
                url: 'sendmail.php',
                type: 'POST',
                data: $('#contact-index').serialize(),
                beforeSend: function(xhr){
                  $('#submit-btn-index').html('SENDING...');
                },
                success: function(response){
                  if(response){
                    console.log(response);
                    if(response['isSuccess']){
                    //  $('#msg-index').html('<div class="alert alert-success">'+ response['msg']  +'</div>');
                      $('input, textarea').val(function() {
                         return this.defaultValue;
                      });
                      window.location.href = "https://pinnacleicons.com/lp/website-design/thankyou.php";
                    }
                    else{
                      $('#msg-index').html('<div class="alert alert-danger">'+ response['msg'] +'</div>');
                    }
                  }
                },
                error: function(){
                  $('#msg-index').html('<div class="alert alert-danger">Errors occur. Please try again later.</div>');
                },
                complete: function(){
                  $('#submit-btn-index').html('SUBMIT');
                }
              });
          });
        });

 //Modal Form
$(document).ready(function(){
  $('#submit-btn-modal').click(function(event){
    event.preventDefault();
     $.ajax({
        dataType: 'JSON',
        url: 'sendmail.php',
        type: 'POST',
        data: $('#contact-modal').serialize(),
        beforeSend: function(xhr){
          $('#submit-btn-modal').html('SENDING...');
        },
        success: function(response){
          if(response){
            console.log(response);
            if(response['isSuccess']){
            //  $('#msg-modal').html('<div class="alert alert-success">'+ response['msg']  +'</div>');
              $('input, textarea').val(function() {
                 return this.defaultValue;
              });
              window.location.href = "";
               
            }
            else{
              $('#msg-modal').html('<div class="alert alert-danger">'+ response['msg'] +'</div>');
            }
          }
        },
        error: function(){
          $('#msg-modal').html('<div class="alert alert-danger">Errors occur. Please try again later.</div>');
        },
        complete: function(){
          $('#submit-btn-modal').html('SUBMIT');
        }
      });
  });
});

        //recaptcha
        // document.getElementById("my_captcha_form_1").addEventListener("submit",function(evt)
        // {
        //     var response = grecaptcha.getResponse();
        //     if(response.length == 0)
        //     {
        //         alert("please verify you are humann! my_captcha_form_1");
        //         evt.preventDefault();
        //         return false;
        //     }
        // });
        // document.getElementById("my_captcha2").addEventListener("submit",function(evt)
        // {
        //     var response = grecaptcha.getResponse();
        //     if(response.length == 0)
        //     {
        //         alert("please verify you are humann! my_captcha2");
        //         evt.preventDefault();
        //         return false;
        //     }
        // });
        // document.getElementById("banforms").addEventListener("submit",function(evt)
        // {
        //     var response = grecaptcha.getResponse();
        //     if(response.length == 0)
        //     {
        //         alert("please verify you are humann! banforms");
        //         evt.preventDefault();
        //         return false;
        //     }
        // });
        

</script>


</body>
</html>
