<?php include 'includes/header.php';?>
        <div class="header_padding"></div>
            <div id="thankyou" role="main">
               <div class="contain">
                    <h1>Thank You For Your Interest!</h1>
                    <a class="button" href="https://pinnacleicons.com/lp/website-design/">Go Back to Home Page</a>
               </div>
            </div>
        </div>
<?php include 'includes/footer.php';?>
