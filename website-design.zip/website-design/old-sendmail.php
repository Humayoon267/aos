<?php
if(isset($_POST)){
require('phpmailer/PHPMailerAutoload.php');
   $mail = new PHPMailer;
   
    $name = trim($_POST['name']);
    
    $email = trim($_POST['email']);
    $phone = $_POST['phone'];
    // $phone = trim($_POST['phone']);
    // $forecasted = trim($_POST['forecasted']);
    // $interested = trim($_POST['interested']);
    $message = trim($_POST['message']);
    
    $user_ip = trim($_POST['user_ip']);
    // $country_name = trim(isset($_POST['country_name'])?$_POST['country_name']:'Not Entered');
    // $country_code = trim($_POST['country_code']);
    // $region_name = trim($_POST['region_name']);
    // $city = trim($_POST['city']);
    // $zip_code = trim($_POST['zip_code']);
    // $time_zone = trim($_POST['time_zone']);
    $page_link = trim($_POST['page_link']);
  
    
    
    
    
    
    
    
    //$ip_info = $_POST['ip_info'];

    if($name && $email && $phone){
       
  		if(!filter_var($email, FILTER_VALIDATE_EMAIL))
  		{
        $isSuccess = false;
        $msg = 'Invalid email. Please check';
      }
       elseif(!preg_match("/^[+0-9 .\-]{10,15}$/", $phone)) {
          
          
          $isSuccess = false;
            $msg = 'Incorrect phone number';
          
      }

      else{
           ;
          $body='';

$body='<table style="width:100%;" border="1">';

foreach($_POST as $key=>$value){

    $_key=ucwords(str_replace('_',' ',$key));

    $body.="<tr><td>$_key</td><td>$value</td></tr>";

}

$body.='</table>';
            $headers = "MIME-Version: 1.0" . "\r\n";

            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $subject = 'Lead LP - '.$name.' - Pinnacle Icons';
            $message = $body;
            
            $headers .= 'From: noreply@pinnacleicons.com'       . "\r\n" .
                         'Reply-To: noreply@pinnacleicons.com' . "\r\n" .
                         'X-Mailer: PHP/' . phpversion();
        
            mail('bundle@thecreativewebsitestudios.com,alex.wright@creativewebsitestudios.com', $subject, $message, $headers);
            if(mail){
                $isSuccess = true;
              $msg = 'Thank you for contacting us, we will get back to you soon';
            }else{
                echo 'Message could not be sent.';
              echo 'Mailer Error: ' . $mail->ErrorInfo;
            }
            
              
         
        //   $mail = new PHPMailer;
          
        //   $mail->SMTPOptions = array(
        //         'ssl' => array(
        //             'verify_peer' => false,
        //             'verify_peer_name' => false,
        //             'allow_self_signed' => true
        //         )
        //     );
    
         
        //   $mail->isSMTP();                                      // Set mailer to use SMTP
        //   $mail->Host = 'mail.pinnacleicons.com'; // Specify main and backup SMTP servers
        //   $mail->SMTPAuth = true;                               // Enable SMTP authentication
        //   $mail->Username = 'noreply@pinnacleicons.com';                 // SMTP username
        //   $mail->Password = 'sb*D%fMpOH5R';                           // SMTP password
        //   $mail->SMTPSecure = 'ssl';                            // Enable TLS encryption, `ssl` also accepted
        //   $mail->Port = 465;                                    // TCP port to connect to
        // // $mail->SMTPDebug = 3; 
        //  $mail->setFrom('noreply@pinnacleicons.com', $name.'- LP - Lead - Pinnacle Icons ');
        //   $mail->addAddress('alex.wright@creativewebsitestudios.com', 'Pinnacle Icons');     // Add a recipient
        // $mail->AddCC('bundle@thecreativewebsitestudios.com', 'Pinnacle Icons');
        //   //$mail->addReplyTo($email, $name);
        //   //$mail->addBcc('');
        //   $mail->isHTML(true);                                  // Set email format to HTML

        //   $mail->Subject = 'Lead LP - '.$name.' - Pinnacle Icons';
        //  $mail->Body    = 'Name: ' . $name . ' <br />
        //                     Email: ' . $email . ' <br />
        //                     Phone: ' . $phone . ' <br />
        //                     Message: ' . $message . ' <br />
        //                     User ip: ' . $user_ip . ' <br />
                           
        //                     Page URL: ' . $page_link
        //                  ;

        //   if(!$mail->send()) {
        //       echo 'Message could not be sent.';
        //       echo 'Mailer Error: ' . $mail->ErrorInfo;
        //   } else {
        //       $isSuccess = true;
        //       $msg = 'Thank you for contacting us, we will get back to you soon';
        
        //   }
      }
    }
    else{
        $isSuccess = false;
        $msg = 'Please fill in all the fields.';
    }
    $data = array(
        'isSuccess' => $isSuccess,
        'msg' => $msg
    );

    echo json_encode($data);
    
}else{
    echo "No data found";
}
?>
